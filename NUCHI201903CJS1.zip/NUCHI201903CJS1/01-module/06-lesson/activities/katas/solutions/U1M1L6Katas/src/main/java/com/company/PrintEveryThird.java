package com.company;

public class PrintEveryThird {

    public static void main(String[] args) {

        // Write code that goes through an array of ints and prints
        // every 3rd element to the screen.  This code should work for
        // any size array.

        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

        for(int i = 0; i < numbers.length; i++) {
            if( (i + 1) % 3 == 0 ) {
                System.out.println(numbers[i]);
            }
        }

    }

}
