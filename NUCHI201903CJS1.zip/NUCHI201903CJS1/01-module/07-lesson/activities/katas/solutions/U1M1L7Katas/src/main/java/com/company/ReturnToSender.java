package com.company;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class ReturnToSender {

    public static void main(String[] args) throws Exception {

        // write the envelope to the file
        PrintWriter out = new PrintWriter(new FileWriter("envelope.txt"));
        out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        out.println("| John Smith                                                 |");
        out.println("| 123 Main St.                                               |");
        out.println("| Mytown, AZ 12345                                           |");
        out.println("|                                                            |");
        out.println("|                      George Williams                       |");
        out.println("|                      456 2nd Ave. Apt 3B                   |");
        out.println("|                      Hometown, AK 98765                    |");
        out.println("|                                                            |");
        out.println("|                                                            |");
        out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        out.flush();
        out.close();

        // read the envelop and print to the screen
        Scanner sc = new Scanner(new BufferedReader(new FileReader("envelope.txt")));

        while (sc.hasNextLine()) {
            String currentLine = sc.nextLine();
            System.out.println(currentLine);
        }

        sc.close();


    }
}
