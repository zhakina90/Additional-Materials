# Lesson Overview: JdbcTemplates
This lesson shows learners how to use SQL and Java to manipulate data in a relational database. Learners are shown how to use test-driven development (TDD) to create these data access components.

## Topics

* Project creation
    * Spring Initializr
    * Database schema
* Data transfer object (DTO) design
* Data access object (DAO) interface design
* TDD and unit/integration tests
* Database connection configuration
* Prepared statements
* Row mapper methods
* JdbcTemplate methods
    * ```update```
    * ```queryForObject```
    * ```query```


## Assessments

* In class: Record Collection DAO
* Car Lot DAO
* Coffee Inventory DAO
* Video Game Collection DAO

## Required Software and Resources

* Java 8
* IntelliJ IDEA
* MySQL
* MySQL Workbench
* Chrome

## Approach

This lesson assumes that learners have basic SQL and Java skills. This lesson brings those skills together, showing learners how to write Java code that interacts with relational datbases. 

The material starts with the Java side of the equation where it shows learners how to design Java data transfer objects (DTOs) based on a given relational schema. This is followed by guidance for designing a DAO interface for creating, reading, updating, and deleting the database entries on which the DTOs are based. Learners are then shown how to use test-driven development (TDD) and JUnit to create unit/integration tests for their DAO interface before any of the code is developed. 

The material covers the concept of Red/Green/Refactor as an approach to software development. Finally, learners are show how to implement the DAO interface using Spring JdbcTemplates and prepared statements.

## Assumptions

* Understanding of basic SQL (insert, select, update, delete, join)
* Undertanding of primary and foreign keys
* Ability to use MySQL and MySQL Workbench to create schemas and execute SQL scripts
* Understanding of the Java language
* Ability to create and run Spring Boot projects using Spring Initializr
* Understanding of Maven project structure and dependency management
* Ability to use Java annotations

---

© 2019 Trilogy Education Services
