package com.company;

import java.io.*;
import java.util.Scanner;

public class AppendMe {

    public static void main(String[] args) throws IOException {

        // Get the input from the user
        Scanner consoleScanner = new Scanner(System.in);
        System.out.println("Please enter text to add to the input file: ");
        String input = consoleScanner.nextLine();
        consoleScanner.close();

        // Write the input to the file
        PrintWriter out = new PrintWriter(new FileWriter("input.txt", true));
        out.println(input);
        out.flush();
        out.close();

        // Read the file and print to the screen
        Scanner fileScanner = new Scanner(new BufferedReader(new FileReader("input.txt")));

        while (fileScanner.hasNextLine()) {
            String currentLine = fileScanner.nextLine();
            System.out.println(currentLine);
        }

        fileScanner.close();

    }
}
