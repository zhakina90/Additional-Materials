# Requirements

The purpose of this lab is for you to gain experience with loops and conditionals. Your program must do the following:

-	Print out the numbers from 1 to 100 with the following exceptions:
    -	If the number is a multiple of 3, print FIZZ instead of the number.
    -	If the number is a multiple of 5, print BUZZ instead of the number.
    -	If the number is a multiple of 3 and 5, print FIZZBUZZ instead of the number.

---
© 2019 Trilogy Education Services
