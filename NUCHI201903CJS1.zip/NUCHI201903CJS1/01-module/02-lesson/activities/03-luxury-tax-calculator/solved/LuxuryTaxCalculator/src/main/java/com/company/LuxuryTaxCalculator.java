package com.company;
import java.util.Scanner;

public class LuxuryTaxCalculator {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter all values without a dollar sign or commas");

        System.out.print("What is Player 1's Salary? ");
        int player1Salary = Integer.parseInt(scan.nextLine());

        System.out.print("What is Player 2's Salary? ");
        int player3Salary = Integer.parseInt(scan.nextLine());

        System.out.print("What is Player 3's Salary? ");
        int player2Salary = Integer.parseInt(scan.nextLine());

        int total = player1Salary + player2Salary + player3Salary;

        System.out.format("The team total salary is $%d%n", total);

        if(total > 40000000) {
            System.out.format("Your team owes a luxury tax in the amount of $%f", total * 0.18);
        }
    }
}
