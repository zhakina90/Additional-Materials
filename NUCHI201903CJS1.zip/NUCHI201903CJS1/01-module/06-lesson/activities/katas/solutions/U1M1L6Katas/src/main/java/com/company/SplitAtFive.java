package com.company;

public class SplitAtFive {

    public static void main(String[] args) {

        // Write code that does the following with an array of ints. Your
        // code should work for an array of any size.
        //
        // 1. Determines how many values are less than 5
        // 2. Creates two new arrays. One will hold that values under 5 and the
        //    other will hold the values over five
        // 3. Copies all the values under five to one array and the values over 5 to
        //    other array
        // 4. Prints all three arrays to the screen


        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

        int numLessThanFive = 0;

        for(int element : numbers) {
            if( element < 5 ){
                numLessThanFive++;
            }
        }

        int [] lessThanFive = new int[numLessThanFive];
        int [] moreThanFive = new int[numbers.length - numLessThanFive];

        int indexLessThanFive = 0;
        int indexMoreThanFive = 0;

        for(int element : numbers) {
            if(element < 5) {
                lessThanFive[indexLessThanFive] = element;
                indexLessThanFive++;
            } else {
                moreThanFive[indexMoreThanFive] = element;
                indexMoreThanFive++;
            }
        }

        System.out.println("----------------");
        System.out.println("Original Array");

        for(int element : numbers) {
            System.out.println(element);
        }

        System.out.println("----------------");
        System.out.println("Less Than Five Array");

        for(int element : lessThanFive) {
            System.out.println(element);
        }

        System.out.println("----------------");
        System.out.println("More Than Five Array");

        for(int element : moreThanFive) {
            System.out.println(element);
        }

    }

}
