package io.driveit.crm.dao;

import io.driveit.crm.dto.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
    Customer findByFirstNameAndLastName(String firstName, String lastName);
}
