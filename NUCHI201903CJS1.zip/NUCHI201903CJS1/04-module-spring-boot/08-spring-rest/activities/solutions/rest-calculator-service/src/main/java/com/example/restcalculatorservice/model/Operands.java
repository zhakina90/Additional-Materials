package com.example.restcalculatorservice.model;

public class Operands {

    private int operand1;
    private int operand2;

    public int getOperand1() {
        return operand1;
    }

    public void setOperand1(int operand1) {
        System.out.println("Calling setOperand1. The value is " + operand1);
        this.operand1 = operand1;
    }

    public int getOperand2() {
        return operand2;
    }

    public void setOperand2(int operand2) {
        System.out.println("Calling setOperand2. The value is " + operand2);
        this.operand2 = operand2;
    }
//    private Integer operand1;
//    private Integer operand2;
//
//    public Integer getOperand1() {
//        return operand1;
//    }
//
//    public void setOperand1(Integer operand1) {
//        this.operand1 = operand1;
//    }
//
//    public Integer getOperand2() {
//        return operand2;
//    }
//
//    public void setOperand2(Integer operand2) {
//        this.operand2 = operand2;
//    }
}
