package com.company;

public class AChattyProgram {

    public static void main(String[] args) {

        System.out.println("Hi!");
        System.out.println("How are you?");
        System.out.println("I'm fine!");
        System.out.println("Doing really well in fact...");
        System.out.println("Isn't it a beautiful day?");
        System.out.println("Smiling is my favorite");
        System.out.println("Good bye!!");
    }
}
