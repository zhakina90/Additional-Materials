package com.company;

public class LessThanFive {

    public static void main(String[] args) {

        // Write code that goes through an array of ints and prints out all values less than 5 and
        // their associated indexes. For example, each time a value under 5 is found your code should
        // print the following:
        //
        // Value 3 found at index 8
        //
        // Where 3 and 8 are replaced by the actual values your code found.
        //
        // Your code must work for any size array.

        int [] numbers = {2, 4, 5, 3,
                          7, 6, 1, 9,
                          10, 13, 56, 43,
                          17, 89, 3, 24,
                          37, 12, 101, 112};

        for(int i = 0; i < numbers.length; i++) {
            if( numbers[i] < 5 ) {
                System.out.format("Value %d found at index %d%n", numbers[i], i);
            }
        }
    }

}
