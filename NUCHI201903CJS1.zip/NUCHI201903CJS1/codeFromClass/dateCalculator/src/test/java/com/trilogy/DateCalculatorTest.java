package com.trilogy;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class DateCalculatorTest {
    private DateCalculator dateCalculator;

    @Before
    public void instantiateDateCalculator() {
        dateCalculator = new DateCalculator();
    }

    @Test
    public void june2019Has30Days() {
        int days = dateCalculator.calculateNumberOfDaysInMonth(2019, 6);
        Assert.assertEquals(days, 30);
    }

    @Test
    public void feb2019Has28Days() {
        int days = dateCalculator.calculateNumberOfDaysInMonth(2019, 2);
        Assert.assertEquals(days, 28);
    }

    @Test
    public void decemberHas31Days() {
        int days = dateCalculator.calculateNumberOfDaysInMonth(2019, 12);
        Assert.assertEquals(days, 31);
    }

    @Test
    public void leapYearFebDays() {
        int days = dateCalculator.calculateNumberOfDaysInMonth(2020, 2);
        Assert.assertEquals(days, 29);
    }

    @Test
    public void marchHas31Days() {
        int days = dateCalculator.calculateNumberOfDaysInMonth(2020, 3);
        Assert.assertEquals(days, 31);
    }

    @Test
    public void augustHas31Days() {
        int days = dateCalculator.calculateNumberOfDaysInMonth(2020, 8);
        Assert.assertEquals(days, 31);
    }

    @Test
    public void januaryHas31Days() {
        int days = dateCalculator.calculateNumberOfDaysInMonth(2020, 1);
        Assert.assertEquals(days, 31);
    }

    @Test
    public void february1800Has28DaysBecauseItsDivisibleBy100AndNot400() {
        int days = dateCalculator.calculateNumberOfDaysInMonth(1800, 2);
        Assert.assertEquals(days, 28);
    }

    @Test
    public void februaryEvery400YearsHas29DaysBecauseItsDivisibleBy400() {
        int days = dateCalculator.calculateNumberOfDaysInMonth(800, 2);
        Assert.assertEquals(days, 29);
    }

    @Test
    public void monthsWith31DaysHave31Days() {
        //January
        int days = dateCalculator.calculateNumberOfDaysInMonth(800, 1);
        Assert.assertEquals(days, 31);
        //March
        days = dateCalculator.calculateNumberOfDaysInMonth(800, 3);
        Assert.assertEquals(days, 31);
        days = dateCalculator.calculateNumberOfDaysInMonth(800, 5);
        Assert.assertEquals(days, 31);
        days = dateCalculator.calculateNumberOfDaysInMonth(800, 7);
        Assert.assertEquals(days, 31);
        days = dateCalculator.calculateNumberOfDaysInMonth(800, 8);
        Assert.assertEquals(days, 31);
        days = dateCalculator.calculateNumberOfDaysInMonth(800, 10);
        Assert.assertEquals(days, 31);
        days = dateCalculator.calculateNumberOfDaysInMonth(800, 12);
        Assert.assertEquals(days, 31);
    }
}
