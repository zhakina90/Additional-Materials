package com.example.cinder.domain;

import java.util.Objects;

public class Dislike {
    private int personId;

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dislike dislike = (Dislike) o;
        return personId == dislike.personId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(personId);
    }
}
