package vending;

/**
 * A parameterized utility class to hold two different object.
 */

public class Bucket<E1, E2> {

    private E1 firstElement;
    private E2 secondElement;

    public Bucket(E1 firstElement, E2 secondElement){
        this.firstElement = firstElement;
        this.secondElement = secondElement;
    }

    public E1 getFirstElement(){
        return firstElement;
    }

    public E2 getSecondElement(){
        return secondElement; }
    }
