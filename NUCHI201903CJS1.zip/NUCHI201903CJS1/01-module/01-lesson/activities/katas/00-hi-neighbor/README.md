# Hi Neighbor
## Requirements
This assignment will be pair programmed following the instructions given in class.

1. Create a new IntelliJ project called HiNeighbor following the same steps you took to create HelloWorld.
1. Have your pair tell you what code to type in your main method to produce the following output about your pair:
```
Hi Neighbor!
My name is PAIR NAME.
I'm from PAIR HOME TOWN.
I have NUMBER siblings.
COLOR is my favorite color.
I listen to MUSIC GENRE music.
My favorite hobby is HOBBY.
Nice to meet you!
Good bye!!!
```

---
© 2019 Trilogy Education Services