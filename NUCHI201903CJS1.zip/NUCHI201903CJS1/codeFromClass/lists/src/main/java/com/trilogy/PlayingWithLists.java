package com.trilogy;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PlayingWithLists {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        System.out.println("How many names do we have? " + names.size());

        names.add("Joe");
        System.out.println("How many names do we have? " + names.size());

        String tempName = names.get(0);
        System.out.println("tempname is " + tempName);

        names.add("Sally");
        names.remove(1);

        names.add("Bob");
        names.add("Carol");
        names.add("Alice");
        names.size();
        System.out.println("How many names do we have? " + names.size());

        Iterator<String> it = names.iterator();

        while (it.hasNext()) {
            System.out.println("Name: " + it.next());
        }
        names.clear();
        System.out.println("How many names do we have? " + names.size());

        List<Integer> intList = new ArrayList<>();
        intList.add(4);

        intList.add(6);

        int x = intList.get(0) + intList.get(1);

        System.out.println("X is " + x);
    }
}
