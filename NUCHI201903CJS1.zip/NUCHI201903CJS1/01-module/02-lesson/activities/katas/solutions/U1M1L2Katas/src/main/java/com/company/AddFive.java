package com.company;
import java.util.Scanner;

public class AddFive {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int sum = 0;

        System.out.print("Enter a number: ");
        sum = sum + Integer.parseInt(scan.nextLine());

        System.out.print("Enter a number: ");
        sum = sum + Integer.parseInt(scan.nextLine());

        System.out.print("Enter a number: ");
        sum = sum + Integer.parseInt(scan.nextLine());

        System.out.print("Enter a number: ");
        sum = sum + Integer.parseInt(scan.nextLine());

        System.out.print("Enter a number: ");
        sum = sum + Integer.parseInt(scan.nextLine());

        System.out.format("The sum of your numbers is %d", sum);
    }
}
