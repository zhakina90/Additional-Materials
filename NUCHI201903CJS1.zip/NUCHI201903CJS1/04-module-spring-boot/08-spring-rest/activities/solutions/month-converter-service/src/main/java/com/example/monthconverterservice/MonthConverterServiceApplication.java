package com.example.monthconverterservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonthConverterServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonthConverterServiceApplication.class, args);
	}

}
