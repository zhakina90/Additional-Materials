package com.example.cinder.domain;

import java.util.Objects;

public class Profile {
    private int id;
    private String name;
    private String bio;
    private int age;
    private int hiking;
    private int dancing;
    private int sports;
    private int reading;
    private int quietNight;
    private int dining;
    private int debate;
    private int club;
    private int politics;
    private int beach;
    private int parties;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getHiking() {
        return hiking;
    }

    public void setHiking(int hiking) {
        this.hiking = hiking;
    }

    public int getDancing() {
        return dancing;
    }

    public void setDancing(int dancing) {
        this.dancing = dancing;
    }

    public int getSports() {
        return sports;
    }

    public void setSports(int sports) {
        this.sports = sports;
    }

    public int getReading() {
        return reading;
    }

    public void setReading(int reading) {
        this.reading = reading;
    }

    public int getQuietNight() {
        return quietNight;
    }

    public void setQuietNight(int quietNight) {
        this.quietNight = quietNight;
    }

    public int getDining() {
        return dining;
    }

    public void setDining(int dining) {
        this.dining = dining;
    }

    public int getDebate() {
        return debate;
    }

    public void setDebate(int debate) {
        this.debate = debate;
    }

    public int getClub() {
        return club;
    }

    public void setClub(int club) {
        this.club = club;
    }

    public int getPolitics() {
        return politics;
    }

    public void setPolitics(int politics) {
        this.politics = politics;
    }

    public int getBeach() {
        return beach;
    }

    public void setBeach(int beach) {
        this.beach = beach;
    }

    public int getParties() {
        return parties;
    }

    public void setParties(int parties) {
        this.parties = parties;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Profile profile = (Profile) o;
        return id == profile.id &&
                age == profile.age &&
                hiking == profile.hiking &&
                dancing == profile.dancing &&
                sports == profile.sports &&
                reading == profile.reading &&
                quietNight == profile.quietNight &&
                dining == profile.dining &&
                debate == profile.debate &&
                club == profile.club &&
                politics == profile.politics &&
                beach == profile.beach &&
                parties == profile.parties &&
                Objects.equals(name, profile.name) &&
                Objects.equals(bio, profile.bio);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, bio, age, hiking, dancing, sports, reading, quietNight, dining, debate, club, politics, beach, parties);
    }
}
