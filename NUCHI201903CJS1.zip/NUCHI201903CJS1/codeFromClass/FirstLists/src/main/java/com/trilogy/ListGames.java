package com.trilogy;

import java.util.*;


public class ListGames {
    public static void main(String[] args) {
        //List<String> names = new ArrayList<String>();

        List<String> moreNames = new ArrayList<>();

        //List<String> gaggleOfNames = new LinkedList<>();

        System.out.println("How many names do we have? " + moreNames.size());

        moreNames.add("Danaerys Targarian");
        System.out.println("How many names do we have? " + moreNames.size());

        String tempName = moreNames.get(0);
        System.out.println("The first name in this list is: " + tempName);

        moreNames.add("Drogon");
        tempName = moreNames.get(1);
        System.out.println("The next name in this list is " + tempName);

        System.out.println("The next name in the list is " + moreNames.add("Hodor"));
        tempName = moreNames.get(2);

        System.out.println("Now tempName is " + tempName);

        System.out.println("How many names do we have? " + moreNames.size());
        moreNames.remove(1);
        System.out.println("How many names do we have? " + moreNames.size());
        tempName = moreNames.get(1);
        System.out.println("tempName is now the Arturo thing: " + tempName);

        //add an element at an index
        moreNames.add(1, "Robb");
        System.out.println("How many names do we have? " + moreNames.size());

        //print all the names in the list
        for (String gameOfThronesName : moreNames) {
            System.out.println(gameOfThronesName);
        }

        //search for an item not in the list
        int indexOfTheNameWeAreSearchingFor = moreNames.indexOf("Habib");
        System.out.println("Habib is at index " + indexOfTheNameWeAreSearchingFor);

//        System.out.println("Clearing the list!");
//        moreNames.clear();
        System.out.println("How many names do we have? " + moreNames.size());

        System.out.println("Adding three classmates");
        moreNames.add("Zhamal");
        moreNames.add("Ghazi");
        moreNames.add("Aaron");

//        List<String> moreNames = new ArrayList<>();

        //create an array of names
        String[] namesToAdd = {"Kenesis", "Samat", "Nurgul", "Bria", "Tri", "Jenn", "Ben", "Sophonie"};

        //use a loop to add all those names to the list
        for (String name : namesToAdd) {
            moreNames.add(name);
        }

        System.out.println("Printing list contents");
        for (String element : moreNames) {
            System.out.println(element);
        }

        System.out.println("Removing whatever is at index 1");
        moreNames.remove(1);
        System.out.println("Printing list contents again");
        for (String element : moreNames) {
            System.out.println(element);
        }

        //Starting with a new list so that we can use an iterator
        List<String> presents = new ArrayList<>();
        presents.add("money");
        presents.add("more money");
        presents.add("Derrick Rose");
        presents.add("Ferrari");
        presents.add("House");

        Iterator<String> it = presents.iterator();

        while(it.hasNext()) {
            System.out.println("Bria has another present!!! It's a " + it.next());
        }

        //Create a list of cities
        List<String> myCities = new ArrayList<>();
        myCities.add("Atlanta");
        myCities.add("Monterrey");
        myCities.add("Los Angeles");
        myCities.add("Chicago");

        Iterator<String> itis = myCities.iterator();
        System.out.println();

        while (itis.hasNext()) {
            System.out.println("I like the city of " + itis.next());
        }

        //Wrapper classes
        List<Float> myFloatList = new ArrayList<>();
        List<Long> myLongList = new ArrayList<>();
        List<Boolean> myBooleanList = new ArrayList<>();

        // To add primitive values, use a wrapper class
        List<Integer> myIntList = new ArrayList<>();

        Integer myInteger = new Integer(42);
        myInteger = Integer.valueOf(67);

        //construct an Integer object
        myInteger = new Integer(100);

        int primitiveInt = 100;

        System.out.println("myInteger is an object with value " + myInteger);
        System.out.println("primitiveInt is a primitive int with value" + primitiveInt);
        if (primitiveInt == myInteger) {
            System.out.println("These evaluate to equal");
        } else {
            System.out.println("These are not equal");
        }
        myIntList.add(myInteger);
        myIntList.add(125);
        myIntList.add(primitiveInt);

        // java unboxes wrapper objects when the context requires.
        //myIntList contains integer objects, but java lets us assign the object value to the primitive by unboxing the
        //object
        int anotherInt = myIntList.get(1);
        System.out.println("Unboxed integer anotherInt is " + anotherInt);

        int y = myInteger + 25;
        System.out.println("The sum of the primitive 25 and the object myInteger is " + y);
    }
}
