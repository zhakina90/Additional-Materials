package com.company;

public class ReverseAndPrint {

    public static void main(String[] args) {

        // Write code that does the following with an array of ints. Your code should
        // work for an array of any size.
        //
        // 1. Prints the array to the screen
        // 2. Reverses the array (you must do this manually - don't use library helpers!)
        // 3. Prints the reversed array to the screen.

        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

    }

}
