package com.company;
import java.util.Scanner;

public class AverageThree {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Enter a number: ");
        float num1 = Float.parseFloat(scan.nextLine());

        System.out.print("Enter a number: ");
        float num2 = Float.parseFloat(scan.nextLine());

        System.out.print("Enter a number: ");
        float num3 = Float.parseFloat(scan.nextLine());

        System.out.format("The average of these numbers is %f", (num1 + num2 + num3)/3 );
    }
}
