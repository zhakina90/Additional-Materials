package com.company;
import java.util.Scanner;

public class AddFiveAndDouble {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = Integer.parseInt(scan.nextLine());

        System.out.format("Your number plus five then doubled is %d", (num + 5)*2 );
    }
}
