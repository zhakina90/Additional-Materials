package com.company;
import java.util.Scanner;

public class MultiplyThree {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num1 = Integer.parseInt(scan.nextLine());

        System.out.print("Enter a number: ");
        int num2 = Integer.parseInt(scan.nextLine());

        System.out.print("Enter a number: ");
        int num3 = Integer.parseInt(scan.nextLine());

        System.out.format("The product of these numbers is %d", num1 * num2 * num3);
    }
}