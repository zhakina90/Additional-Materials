package com.company.collections;

import java.util.*;

public class WordListLinkedList {

    public static void main(String[] args) {

        List<String> wordList = new LinkedList<>();

        wordList.add("final");
        wordList.add("finally");
        wordList.add("for");
        wordList.add("while");
        wordList.add("if");
        wordList.add("transient");
        wordList.add("goto");
        wordList.add("throw");
        wordList.add("throws");
        wordList.add("class");

        for(String element : wordList) {
            System.out.println(element);
        }

    }

}
