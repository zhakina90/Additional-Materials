package com.company.collections;

import java.util.*;

public class PrintSet {

    public static void main(String[] args) {
        Set<Integer> intSet = new HashSet<>();

        intSet.add(5);
        intSet.add(1);
        intSet.add(2);
        intSet.add(1);
        intSet.add(4);
        intSet.add(1);
        intSet.add(5);

        System.out.println(intSet);

        Iterator itr = intSet.iterator();

        while(itr.hasNext()) {
            System.out.println(itr.next());
        }

    }
}
