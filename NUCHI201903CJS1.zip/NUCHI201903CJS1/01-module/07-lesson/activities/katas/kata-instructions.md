## List of Katas

## Return to Sender 
1. Create a project called ```ReturnToSender```.
1. Write code that prints the following "envelope" to a file called ```envelope.txt```, reads it back from the file, and then prints it to the screen.

```
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
| John Smith                                                 |
| 123 Main St.                                               |
| Mytown, AZ 12345                                           |
|                                                            |
|                      George Williams                       |
|                      456 2nd Ave. Apt 3B                   |
|                      Hometown, AK 98765                    |
|                                                            |
|                                                            |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

```
## Append Me
1. Create a project called ```AppendMe```.
1. Write code that takes input from the user, appends it to a file called ```input.txt```, and then prints the entire contents of the file to the screen.

**Hint**: You can open a file for appending by providing a second parameter with the value ```true``` to the FileWrite constructor:

    ```new FileWriter("myFile.txt", true)```

---
© 2019 Trilogy Education Services
