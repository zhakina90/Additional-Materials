# A Postcard from Me
## Requirements
1. Create a new IntelliJ project called APostcardFromMe following the same steps you took to create HelloWorld.
1. Add code to your main method that produces output similar to the following:
```
*------------------------------------------------------------------*
| John Smith                                                       |
| 123 Main Street                                                  |
| Hometown, MN 55555                                               |
|                                                                  |
|                        Jane Doe                                  |
|                        345 Mockingbird Ln.                       |
|                        Smalltown, OR 99999                       |
|                                                                  |
|                                                                  |
*------------------------------------------------------------------*
```

---
© 2019 Trilogy Education Services