# Programming by Doing

1. Create a new IntelliJ project called <Firsname><Lastname>U1M2L1PBD where ```Firstname``` and ```Lastname``` are your first name and last name, respectively.
1. Implement solutions for exercises 177–184 at [Programming by Doing](https://programmingbydoing.com/).
   * The solution for each problem should be in its own Java file.




---
© 2019 Trilogy Education Services