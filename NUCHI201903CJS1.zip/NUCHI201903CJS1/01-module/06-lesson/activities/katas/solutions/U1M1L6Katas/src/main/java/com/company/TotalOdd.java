package com.company;

public class TotalOdd {

    public static void main(String[] args) {

        // Write code that finds the sum of all the values
        // of the odd numbered indexes in an array of ints.
        // Your code should work for an array of any size.

        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

        int total = 0;

        for(int i = 1; i < numbers.length; i = i + 2) {
            total += numbers[i];
        }

        System.out.println("The sum of all odd indexed elements in the array is " + total);

    }

}
