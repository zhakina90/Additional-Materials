# Marvel Table
## Requirements
1. Create a new IntelliJ project called MarvelTable following the same steps you took to create HelloWorld.
1. Add code to your main method that produces output similar to the following:
```
-------------------------------------------------------------
|   Hero              |   Affiliation     |   Power         |
-------------------------------------------------------------
|   Captain America   |   The Avengers    |   Peak Human    |
-------------------------------------------------------------
|   Wolverine         |   The X-Men       |   Healing/Claws |
-------------------------------------------------------------
|   Cyclops           |   The X-Men       |   Eye Beam      |
-------------------------------------------------------------
|   Domino            |   X-Force         |   Luck          |
-------------------------------------------------------------
```

---
© 2019 Trilogy Education Services