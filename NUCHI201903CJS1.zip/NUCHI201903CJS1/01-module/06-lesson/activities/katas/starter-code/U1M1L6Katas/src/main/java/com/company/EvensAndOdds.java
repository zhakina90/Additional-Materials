package com.company;

public class EvensAndOdds {

    public static void main(String[] args) {

        // Create two new 6 element String arrays. Put the values of the even indices in one and the values
        // of the odd indices in the other.

        String[] strings = {"foo", "bar", "baz",
                            "Java", "C#", "C++",
                            "Python", "C", "JavaScript",
                            "Apple", "Dell", "Lenovo"};

    }

}
