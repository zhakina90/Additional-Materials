# A Chatty Program
## Requirements
1. Create a new IntelliJ project called AChattyProgram following the same steps you took to create HelloWorld.
1. Add code to your main method that produces the following output:
```
Hi!
How are you?
I'm fine!
Doing really well in fact...
Isn't it a beautiful day?
Smiling is my favorite!
Good bye!!!
```

---
© 2019 Trilogy Education Services