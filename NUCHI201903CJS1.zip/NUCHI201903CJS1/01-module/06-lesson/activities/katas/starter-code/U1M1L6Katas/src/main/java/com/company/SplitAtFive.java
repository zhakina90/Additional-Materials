package com.company;

public class SplitAtFive {

    public static void main(String[] args) {

        // Write code that does the following with an array of ints. Your
        // code should work for an array of any size.
        //
        // 1. Determines how many values are less than 5
        // 2. Creates two new arrays. One will hold that values under 5 and the
        //    other will hold the values over five
        // 3. Copies all the values under five to one array and the values over 5 to
        //    other array
        // 4. Prints all three arrays to the screen


        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

    }

}
