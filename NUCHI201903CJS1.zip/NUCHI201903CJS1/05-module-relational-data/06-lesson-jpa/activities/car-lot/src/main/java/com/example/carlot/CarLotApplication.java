package com.example.carlot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarLotApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarLotApplication.class, args);
	}

}
