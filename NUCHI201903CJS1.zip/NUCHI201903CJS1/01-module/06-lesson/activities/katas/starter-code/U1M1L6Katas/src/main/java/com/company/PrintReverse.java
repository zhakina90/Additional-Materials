package com.company;

public class PrintReverse {

    public static void main(String[] args) {

        // Write code that prints the elements of an array of ints
        // to the screen in reverse order. This code should work for any
        // size array.

        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

    }

}
