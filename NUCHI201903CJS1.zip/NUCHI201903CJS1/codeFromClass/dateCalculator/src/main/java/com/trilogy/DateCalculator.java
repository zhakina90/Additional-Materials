package com.trilogy;

public class DateCalculator {
    public static void main(String[] args) {
        System.out.println("Hello, world! I'm the date calculator!");
    }

    public int calculateNumberOfDaysInMonth(int year, int month) {
        int returnVal = 100;
        switch (month) {
            case 2:
                if (year % 400 == 0) {
                    returnVal = 29;
                } else if (year % 100 == 00) {
                    returnVal = 28;
                } else if (year % 4 == 0) {
                    returnVal = 29;
                } else {
                    returnVal = 28;
                }
                break;
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                returnVal = 31;
                break;
            default:
                returnVal = 30;
                break;
        }
        return returnVal;
    }
}
