## List of Katas

1. Range Checker: Write a program that asks the user for a number between 15 and 32 and then prints that number back out to the screen. The program must continue to prompt the user until they provide a number that is in range.
1. Count to: Write a program that takes a user input and prints a count from 0 to that input.
1. Count by Two: Same as above, but counts by 2.
1. Count by 13: Same as above, just a weird value.
1. Even or Odd: Write a program that gets user input (an int) and prints whether it is even or odd.
1. Is a Java Keyword?: Write a program that get user input (a String) and print out whether or not it is a Java keyword.  They will have to get the list of keywords for the lesson.
1. Your Age Can: Write a program that asks the user's age and then prints out whether that person can:
    * Vote
    * Drink alcohol
    * Be president
    * Is eligible for AARP
    * Can retire
    * Is an octogenerian
    * Is more than a century old
1. Ultimate Question: Write a program that continues to ask for input between 1 and 100 until the user enters 42.
1. Favorite Programming Language: Write a program that continues to ask for the user's favorite programming language until they type in "Java".
1. Age Again: Write a program that asks for the user's age and then asks a follow-up question based on the value:
    * Less than 14: Ask what grade they're in and then prints "Wow [user answer] grade - that sounds exciting!"
    * Between 14 and 18: Ask if they're planning to go to college.  If the answer is yes, ask what college and then print "[user answer] is a great school!".  If the answer is no, ask what they want to do after high school, then print "Wow, <user answer> sounds like a plan!"
    * Greater than 18: Ask what their job is, then print "[user answer] sounds like a great job!"

---
© 2019 Trilogy Education Services