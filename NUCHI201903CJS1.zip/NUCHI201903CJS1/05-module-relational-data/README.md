# Module Overview: Relational Data
Real-world applications track, store, and manipulate data. In order to do this, these applications must be backed by some kind of data repository. The most common type of data repository is the relational database. This module covers modeling these databases, querying the data contained in them, and integrating relational databases with Java applications.

## Homework
There are two homework assignments that should be given out the first day of this module. One involves installing MySQL database and the other involves installing MySQL Workbench. Both of these tools are used later in this module.

**NOTE: Assign these homeworks as the first thing you do with this module.**

## Assumptions
* Basic proficiency in Java

## Approach
This module starts with an overview of relational databases and how these databases are modeled. This is followed by coverage of basic data manipulation using Structured Query Language (SQL). Finally, this module covers integrating relational databases with Java applications using Spring JdbcTemplates and Spring Data JPA.

## Design

### Relational Modeling

* Intro to relational satabases
* Data modeling
* Joins


### SQL Basics

* Basic SQL queries
    * SELECT
    * WHERE
    * ORDER BY
    * JOIN
    * INSERT
    * UPDATE
    * DELETE

### Spring JdbcTemplates

* JdbcTemplate object and SQL queries
    * Prepared statements
    * Query and QueryForObject
    * Dates (LocalDate)
    * Decimal numbers (Big Decimal)    
* RowMappers

### Spring Data JPA

* Repository interfaces
    * Custom query methods
    * Unit tests
* Model annotations
* Database integration 
    * Embedded databases
    * MySQL integration


---
© 2019 Trilogy Education Services
