package com.company;

public class EvensAndOdds {

    public static void main(String[] args) {

        // Create two new 6 element String arrays. Put the values of the even indices in one and the values
        // of the odd indices in the other.

        String[] strings = {"foo", "bar", "baz",
                            "Java", "C#", "C++",
                            "Python", "C", "JavaScript",
                            "Apple", "Dell", "Lenovo"};

        String[] evens = new String[6];
        String[] odds = new String[6];

        for(int i = 0; i < strings.length; i++) {
            int currIndex = i/2;
            if( i % 2 == 0 ) {
                evens[currIndex] = strings[i];
            } else {
                odds[currIndex] = strings[i];
            }
        }

        
        System.out.println("----------------");
        System.out.println("Even Indices");

        for(String element : evens) {
          System.out.println(element);
        }

        System.out.println("----------------");
        System.out.println("Odd Indices");

        for(String element : odds) {
          System.out.println(element);
        }

    }

}
