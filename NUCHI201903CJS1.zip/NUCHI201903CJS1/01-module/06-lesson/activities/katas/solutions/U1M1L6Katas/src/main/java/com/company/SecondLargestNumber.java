package com.company;

public class SecondLargestNumber {

    public static void main(String[] args) {

        // Write code that finds the second largest number in an array of ints. Print out both the value
        // and its associated index. Your code should work for any array of any size.

        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

        if( numbers.length < 2) {
          System.out.println("There are fewer than 2 elements in the array");
          System.exit(0);
        }

        int largest, secondLargest;

        if( numbers[1] > numbers[0] ){
          largest = numbers[1];
          secondLargest = numbers[0];
        } else {
          largest = numbers[0];
          secondLargest = numbers[1];
        }

        for(int i = 2; i < numbers.length; i++) {
          if( numbers[i] > largest ) {
            secondLargest = largest;
            largest = numbers[i];
          } else if ( numbers[i] > secondLargest ) {
            secondLargest = numbers[i];
          }
        }

        System.out.println("The second largest number is " + secondLargest);

    }

}
