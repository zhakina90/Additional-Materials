package com.company;

public class Total {

    public static void main(String[] args) {

        // Write code that finds the sum of all the values in an
        // array of ints. Your code should work for an array of any size.

        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

        int total = 0;

        for(int element : numbers) {
          total += element;
        }

        System.out.println("The sum of all elements in the array is " + total);

    }

}
