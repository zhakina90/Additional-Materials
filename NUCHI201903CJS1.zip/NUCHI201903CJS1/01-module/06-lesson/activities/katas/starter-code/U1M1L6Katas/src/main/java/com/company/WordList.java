package com.company;

public class WordList {

    public static void main(String[] args) {

        // Create and initialize two arrays of Strings in two different ways
        // and print the values in the array to the screen. Use the word list
        // below to initialize your arrays.

        // byte case catch class const continue do double else extends
        // final finally for while if transient goto throw throws class


    }

}
