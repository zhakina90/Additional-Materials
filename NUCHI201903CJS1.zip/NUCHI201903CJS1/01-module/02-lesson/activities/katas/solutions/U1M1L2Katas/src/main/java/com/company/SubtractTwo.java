package com.company;
import java.util.Scanner;

public class SubtractTwo {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int diff = Integer.parseInt(scan.nextLine());

        System.out.print("Enter a number: ");
        diff = diff - Integer.parseInt(scan.nextLine());

        System.out.format("The difference between your numbers is %d", diff);
    }
}
