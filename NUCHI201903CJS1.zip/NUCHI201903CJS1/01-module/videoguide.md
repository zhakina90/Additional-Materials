## Complete video guide

### Katas/Activities

#### Lesson 1

Create your first Java program!
[Watch the Video!](https://youtu.be/2JQqZkipmSw)

#### Lesson 2

Create an interactive program that listens for user input!
[Watch the Video!](https://youtu.be/WJZE6VrmDPU)

#### Lesson 3

Create a program to find all the prime numbers up to a user defined number!
[Watch the Video!](https://youtu.be/EAqOsp4W0Mo)

#### Lesson 5

Learn to make and use methods with Java!
[Watch the Video!](https://youtu.be/vJbqYVS9pAU)

#### Lesson 6

Create a program to find the second largest number in an array!
[Watch the Video!](https://youtu.be/pqR0MdyoyQU)
