package com.company;

public class SecondLargestNumber {

    public static void main(String[] args) {

        // Write code that finds the second largest number in an array of ints. Print out both the value
        // and its associated index. Your code should work for any array of any size.

        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

    }

}
