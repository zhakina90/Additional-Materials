# Requirements

Write a program that takes a user input as a ceiling (inclusive) and prints all the prime numbers from 1 to the user input.

---
© 2019 Trilogy Education Services
