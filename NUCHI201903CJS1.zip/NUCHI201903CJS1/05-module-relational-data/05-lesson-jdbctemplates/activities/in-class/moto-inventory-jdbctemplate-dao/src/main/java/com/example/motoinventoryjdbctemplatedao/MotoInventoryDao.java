package com.example.motoinventoryjdbctemplatedao;

import com.example.motoinventoryjdbctemplatedao.domain.Motorcycle;

import java.util.List;

public interface MotoInventoryDao {
    Motorcycle getMotorcycle(int id);

    Motorcycle addMotorcycle(Motorcycle motorcycle);

    void deleteMotorcycle(int id);

    void updateMotorcycle(Motorcycle motorcycle);

    List<Motorcycle> getAllMotorcycles();

    List<Motorcycle> getMotorcycleByMake(String make);
}

// MotoInventoryDaoJdbcTemplateImpl
