import java.util.*;

/**
 * Here's a description of MappyFlappy. A new class brought to you by Cognizant
 *
 */
public class MappyFlappy {
    /**
     * main(String[] args)
     * @param args - these are the console arguments for my method
     */
    public static void main(String[] args) {
        int x = 3;
        int y = 3;
        int z = 3;
        System.out.println("A: " + x +" B: " + y + " C:" + z);

        System.out.println("Click Me!!!  ??");
















//
//        Map<String, String> baseballTeam = new HashMap<>();
//
//        baseballTeam.put("Pitcher", "Mike Foltynewicz");
//        baseballTeam.put("Catcher", "Brian McCann");
//        baseballTeam.put("First Baseman", "Freddie Freeman");
//        baseballTeam.put("Second Baseman", "Ozzie Albies");
//        baseballTeam.put("Third Baseman", "Josh Donaldson");
//        baseballTeam.put("Shortstop", "Dansby Swanson");
//        baseballTeam.put("Left Fielder", "Ronald Acuna, Jr.");
//        baseballTeam.put("Center Fielder", "Ender Inciarte");
//        baseballTeam.put("Right Fielder", "Nick Markakis");
//
//        Set<Map.Entry<String, String>> entrySet = baseballTeam.entrySet();
//        for (Map.Entry<String, String> entry : entrySet) {
//            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
//        }
//
    }


    /** returnAString method
     *
     * @param x
     * @param f
     * @param myParameter
     * @return
     */
    String returnAString(int x, float f, String myParameter) {
        return "Here's that string you asked for: " + myParameter;
    }

}