package com.example.dayconverterservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DayConverterServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DayConverterServiceApplication.class, args);
	}

}
