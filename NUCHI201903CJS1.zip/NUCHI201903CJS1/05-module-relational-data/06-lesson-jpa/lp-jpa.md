# Lesson Plan: Spring Data JPA

Open the [slidedeck](https://docs.google.com/presentation/d/1LQ2fV3AsGoq-3I5KlCMOKryOf8nudK6QX4jsFpa7CCM/edit?usp=sharing) for this lesson.

## Level Set (5 min)
> Set the context, establish authenticity, and generate interest in the lesson's topic. Communicate why this content is important to the learner. 

> Display the Learning Outcomes slide while you present the lesson purpose.

### Purpose
![discuss][discuss]
> The purpose of this lesson is to show learners a code-first approach to creating the data access layer. We assume that learners understand how to implement a DAO with either JDBC or Spring JdbcTemplates. Spring Data JPA automates much of the manual work of implementing a DAO, making rapid prototyping very easy.


### Narrative

"Implementing DAOs with prepared statements and either JDBC or Spring JdbcTemplates is a very database-centric process. We start with the database and then build out from there." 

"Sometimes it is convenient to start with the Java object model and work back from there. This is where technologies like Spring Data JPA come in. They allow us to think more in terms of our code and then work our way toward the database. In this lesson, we'll see how to implement simple DAOs with Spring Data JPA."

### Learning Outcomes

By the end of this lesson, the learner will be able to:

1. Create a Spring Boot project with Spring Data JPA support.
1. Create DTOs based on an existing schema and annotate them so they can be persisted to the schema.
1. Configure a Spring Boot project to automatically create a schema based on existing DTOs with Spring Data JPA annotations.
1. Create unit/integration tests to verify a Spring–Data–JPA-based DAO.
1. Create custom query methods for a Spring–Data–JPA-based DAO.

---

## Repositories (25 min)

> The purpose of this section is to introduce the different types of repository interfaces to give learners an idea of the big picture and what is possible with Spring Data JPA. Emphasize the capabilities of the Crud and JPA repositories and their associated methods. 
>
> You will use a very simple CRM as the example for Spring Data JPA. The data model/table structure is simple: a Customer and associated Notes.
>
> The complete solution for the Simple CRM project is in the ```activities --> in-class --> simple_crm``` folder.

### Repository Overview

* Spring Data JPA takes advantage of object relational mapping (ORM) technology.
    * This technology automatically maps Java objects to database tables.
    * The framework that we'll be using is called Hibernate, but Spring Data JPA abstracts the details of the underlying ORM technology away for us so we don't have to worry about the details of Hibernate.
* Repositories are just interfaces—we do not provide an implementation.
* The base interface (repository) is just a marker interface
    * Don't confuse the respository base interface with the ```@Repository``` annotation. The annotation just makes the Spring framework aware of the interface.
* There are several interfaces derived from a repository:
    * CrudRepository, which has basic CRUD operations
    * PagingAndSortingRepository, which adds paging and sorting capabilities
    * JPARepository, which adds JPA-specific features to the PagingAndSortingRepository
* Go to the JavaDoc for the CrudRepository to show learners the methods that we get for free:
    * count()
    * delete()
    * deleteAll()
    * deleteById()
    * existsById()
    * findAll()
    * findAllById()
    * save()
    * saveAll()

### Defining a Repository

Now we move on to defining a repository:

1. Restate that we just need to declare and interface.
1. The first step is to decide which interface to extend. We will extend JpaRepository.
1. Remind learners that we need the ```@Repository``` annotation.
1. The JpaRepository is a parameterized interface (like Map or List), this means we have to tell the interface what it will be storing and what type the primary key or identifier will be.
    * In our case, we are going to declare two repositories: 
        * One for Customers. Customer ids are integers.
        * One for Notes. Note ids are integers.

This is what it looks like—pretty simple:

```java
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
```

```java
@Repository
public interface NoteRepository extends JpaRepository<Note, Long> {
}
```

### Custom Query Methods

* We can create custom query methods. We are just going to cover the basics here.
* Constructing queries from method names is convenient for prototyping. Just add the method definition to your interface.
* Examples:
    * ```List<Customer> findByLansName(String lastName);```
    * ```List<Customer> findbyLastNameAndCompany(String lastName, String company);```
* Magic!

---

## Model Annotations (30 min)

> The purpose of this section is to show learners how annotations are used to map the DTOs to a database schema. We'll show a code-first approach that creates the database from our objects initially. We will also show that we can use Spring Data JPA with an existing schema later on.

* We use annotations to map our Java objecs to database tables using a code-first approach.
    * We can use Spring Data JPA with existing databases as well. We will demonstrate that later on.
* Discuss the following points about these annotations as you go through the Customer and Note classes:
    * ```@Entity```—class-level annotation that marks this as a persistable object. The class maps to a table.
    * ```@Table```—class-level annotation that specifies the name of the table this class maps to. This is optional. The table name will be the class name if this annotation is not present.
    * ```@Id```—property-level annotation that indicates that this is the primary key/identifier for this class.
    * ```@GeneratedValue```—property-level annotation that indicates that the value for the property is generated.
        * We use ```strategy=GenerationType.AUTO``` because we want the database to auto-generate this value for us. This maps to ```auto_increment``` in MySQL.
    * ```@OneToMany```—property-level annotation that indicates that this is the one side of a one to many relationship.
        * The ```mappedBy``` attribute indicates the propery in the associated object that acts as the foreign key (in our case, it is the ```customerId``` property of the Note class).
        * The ```CascadeType.ALL``` attribute value indicates that we want the database to delete all associated Notes if we delete the Customer.
        * The ```FetchType.EAGER``` attribute value indicates that we want Spring Data JPA to create all the Note objects associated with the Customer when the Customer object is instantiated. The other value for this attribute is ```FetchType.LAZY``` which defers the retrieval of Note data and creation of the Note objects until they are accessed by other code. We generally want all the data up front in a web service because we are shipping the data back to a client of some sort, so we use ```EAGER```.
        * Point out that our Customer class contains a Set of Notes. Spring Data JPA will take care of getting the data from the database and creating the Note objects for us.
    * ```@JsonIgnoreProperties```—class-level annotation that specifies properties that should be ignored when serializing this object to JSON.
        * This is not JPA-specific and is not necessary for DAO functionality but it is needed when we use a JPA DAO in a REST web service where we want to exclude Hibernate-specific fields.

### Customer Class
```java
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name="customer")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String firstName;
    private String lastName;

    private String company;
    private String phone;

    @OneToMany(mappedBy = "customerId", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Set<Note> notes;

    // Getters, setters, equals, and hashCode left out of this listing for brevity
}
```

### Note Class
```java
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name = "note")
public class Note {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String content;
    private Integer customerId;

    // Getters, setters, equals, and hashCode left out of this listing for brevity
}
```

---

## Database Configuration (15 min)

> The purpose of this section is to show learners how to configuration a connection to a MySQL database and how to have Spring Data JPA automatically create the database. Later in the section, we will show how Spring Data JPA can be used with an existing database as well.

* The connection configuration is the same as for JDBC or JdbcTemplate-based projects.
* As always, make sure you have the specified schema (```simple_crm```) created.
* ```spring.jpa.hibernate.ddl-auto``` allows us to specify how we want Spring Data JPA to act when we start our application. Possible values include:
    * ```none```—This is the default for MySQL databases. Spring Data JPA will not do anything to alter the database structure on startup.
    * ```update```—Spring Data JPA will modify the database structure based on the annotations of the Java @Entity classes.
    * ```create```—Spring Data JPA creates the database every time the application is started, but it does not drop the tables when the application quits.
    * ```create-drop```—Spring Data JPA create the data every time the application is started and drops all the tables when the application quits.
    * We use the ```create``` value because we don't have a database. After the initial run, we could switch to ```none``` or ```update``` depending on our project requirements.
* ```spring.jps.show-sql=true``` allows us to see the SQL statements that Spring Data JPA is executing.

```java
spring.datasource.url=jdbc:mysql://localhost:3306/simple_crm
spring.datasource.username=root
spring.datasource.password=root

spring.jpa.hibernate.ddl-auto=create


spring.jpa.show-sql=true
```

* We can also start with an existing database. This SQL script will create a database that works with our Java object model.
* We will demonstrate this below.
* If you start with an existing database, make sure you set ```spring.jpa.hibernate.ddl-auto=none```.

```sql
create schema if not exists simple_crm;
use simple_crm;

create table if not exists customer (
	id int(11) not null auto_increment primary key,
    first_name varchar(50) not null,
    last_name varchar(50) not null,
    company varchar(50) not null,
    phone varchar(50) not null
);

create table if not exists note (
	id int(11) not null auto_increment primary key,
    content varchar(255) not null,
    customer_id int(11) not null
);

/* Foreign Keys: note */
alter table note add constraint fk_note_customer foreign key (customer_id) references customer(id);
```

---

## Simple Unit Tests (15 min)

> The purpose of this section is to show learners how to set up and execute unit/integration tests for their Spring Data JPA DAOs. Learners will be expected to provide a more robust set of tests for their projects.  We assume that learners know how to create JUNit test classes and use the ```@Autowire``` annotation to inject instances into the test class.

1. We annotate the class with:
    * ```@RunWith```—as is standard with testing Spring components
    * ```@SpringBootTest```—also standard when testing Spring components
1. ```@Autowire``` the two repositories.
1. Write tests!



```java
@RunWith(SpringRunner.class)
@SpringBootTest
public class CrmApplicationTests {

	@Autowired
	CustomerRepository customerRepo;

	@Autowired
	NoteRepository noteRepo;

	@Test
	public void contextLoads() {
	}

	@Test
	public void createTest() {
		noteRepo.deleteAll();
		customerRepo.deleteAll();

		Note note = new Note();
		note.setContent("This is a test note");
		Set<Note> noteSet = new HashSet<>();
		noteSet.add(note);

		Note note2 = new Note();
		note2.setContent("This is the SECOND test note.");
		noteSet.add(note2);

		Customer customer = new Customer();
        customer.setFirstName("Joe");
        customer.setLastName("Smith");
        customer.setPhone("111-222-3456");
        customer.setCompany("BigCo");
        customerRepo.save(customer);
        note.setCustomerId(customer.getId());
        note2.setCustomerId(customer.getId());

		noteRepo.save(note);
		noteRepo.save(note2);

		List<Customer> customerList = customerRepo.findAll();
		assertEquals(1, customerList.size());

		noteSet =  customerList.get(0).getNotes();
		assertEquals(2, noteSet.size());
		
	}
}
```

---

## Instructor Do: Demo Repositories (20 min)
![show-code][show-code]

> The purpose of this demonstration is to show learners that  our code can work completely code-first (no existing database) or with an existing database.

1. Open the simple_cms project in IntelliJ.
1. Open MySQL Workbench.
1. Make sure you have the ```simple_cms``` schema created.
    * Make sure all tables are dropped.
1. Show learners the ```application.properties``` file and that you have configured Spring Data JPA to create the database on application startup: ```spring.jpa.hibernate.ddl-auto=create```.
1. Run the unit test class and show that the tests pass.
1. Go to MySQL Workbench and show that there is data in the newly created tables.
1. Drop the tables from the ```simple_cms``` schema.
1. Run the SQL DDL script above to create the tables.
1. Go back to IntelliJ.
1. Change the auto-create setting to ```spring.jpa.hibernate.ddl-auto=none```.
1. Run the test class and show that the tests pass.
1. Go to MySQL Workbench and show that there is data in the tables.

---

## Recap (10 min)
![take note icon][take-note]

This lesson showed how to use Spring Data JPA to create DAO components. The main takeaways from this lesson are:
* Spring Data JPA is build on top of ORM technology. We use Hibernate here.
* Spring Data JPA DAOs are called repositories.
* Creating a repository involves extending an existing repository interface.
* We can create custom query methods by declaring them in our interface.
 * Java objects are mapped to relational tables using annotations.
* Spring Data JPA can automatically create database tables for us based on the annotation on our object model.
* Spring Data JPA can also be used with existing databases.

---
© 2019 Trilogy Education Services

[present]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-present/res/mipmap-hdpi/icon-present.png "Present"

[discuss]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-discuss/res/mipmap-hdpi/icon-discuss.png "Discuss"

[take-note]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-take-note/res/mipmap-hdpi/icon-take-note.png "Take Note"

[show-code]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-show-code/res/mipmap-hdpi/icon-show-code.png "Show Code"

[code-along]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-code-along/res/mipmap-hdpi/icon-code-along.png "Code Along"

[starter-code]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-starter-code/res/mipmap-hdpi/icon-starter-code.png "Starter Code"

[kata]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-kata/res/mipmap-hdpi/icon-kata.png "Kata"

[time]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-time/res/mipmap-hdpi/icon-time.png "Time"

[warning]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-warning/res/mipmap-hdpi/icon-warning.png "Warning"

[break]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-break/res/mipmap-hdpi/icon-break.png "Break"

[alert]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-alert/res/mipmap-hdpi/icon-alert.png

[need-code]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/need-code-300.png

[need-content]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/need-content-300.png


