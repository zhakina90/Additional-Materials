package com.example.restcalculatorservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestCalculatorServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestCalculatorServiceApplication.class, args);
	}

}
