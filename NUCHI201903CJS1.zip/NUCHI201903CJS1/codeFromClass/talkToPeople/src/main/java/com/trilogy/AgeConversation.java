package com.trilogy;

import java.util.Scanner;

public class AgeConversation {
    public static void main(String[] args) {
        int age = -1;
        age = promptForAgeResilient();

        if (age < 18) {
            System.out.println("Go outside and play");
        } else if (age >= 18 && age <= 65) {
            System.out.println("You are a functioning adult! Go outside and play.");
        } else {
            System.out.println("You're older than 65 and I won't say anything offensive");
            System.out.println("You're older than 65 and I won't say anything offensive");
        }
    }
//    public static void main(String[] args) {
//        int age = -1;
//
//        try {
//            age = promptForAgeSecondImplementation();
//
//            System.out.println("Moving on.");
//
//            if (age < 18) {
//                System.out.println("Go outside and play");
//            } else if (age >= 18 && age <= 65) {
//                System.out.println("You are a functioning adult! Go outside and play.");
//            } else {
//                System.out.println("You're older than 65 and I won't say anything offensive");
//                System.out.println("You're older than 65 and I won't say anything offensive");
//            }
//
//        } catch (Exception ex) {
//            System.out.println("You did not enter a valid age.");
//        } finally {
//            System.out.println("Running the finally block because we always run the finally block if it is present.");
//        }
//        System.out.println("We're done here.");
//    }

    public static int promptForAgeResilient() {
        Scanner input = new Scanner(System.in);


        boolean weCaughtAnException = false;

        int ageToReturn = 1000;
        do {
            try {
                System.out.println("Enter your age: ");
                ageToReturn = Integer.parseInt(input.nextLine());
                weCaughtAnException = false;
            } catch (Exception ex) {
                weCaughtAnException = true;
                System.out.println("You entered a bad value for age. ");
                System.out.println("The exception is " + ex.getClass());
                System.out.println("The message on this exception is " + ex.getMessage());
            }
        } while (weCaughtAnException == true);
        return ageToReturn;

    }

    public static int promptForAgeSecondImplementation() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter your age: ");

        int ageToReturn = 0;

        ageToReturn = Integer.parseInt(input.nextLine());

        System.out.println("Continuing execution.");
        return ageToReturn;
    }

    public static int promptForAge() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter your age: ");

        int ageToReturn = 0;
        try {
            ageToReturn = Integer.parseInt(input.nextLine());
        } catch (Exception ex) {
            System.out.println("You entered a bad value for age. ");
            System.out.println("The exception is " + ex.getClass());
            System.out.println("The message on this exception is " + ex.getMessage());
        }

        System.out.println("Continuing execution.");
        return ageToReturn;
    }
}
