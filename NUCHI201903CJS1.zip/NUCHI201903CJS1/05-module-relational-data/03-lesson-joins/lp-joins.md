# Lesson Plan: Joins

Open the [slidedeck](https://docs.google.com/presentation/d/1n5oHhfGabadxNcsjpRg_3fH2qbPYrA-FLmPSUqQUgC0/edit?usp=sharing) for this lesson.

## Level Set (5 min)
> During this section, you will set the context, establish authenticity, and generate interest in the lesson's topic. This section should communicate why this content is important to the learner. 

> Open and display the Learning Outcomes slide while you present the lesson purpose.

### Purpose
![discuss][discuss]
> The purpose of this lesson is to give learners a high-level conceptual view of joins. Joins are presented in relationship to normalization. Whereas normalization spreads data across several tables for data storage efficiency, joins gather that information back together so it is easy to read.

### Narrative

"Data modeling and normalization aim for data storage efficiency. In the process, database data can be spread across tables. Though this is great for data storage, it is not so great when it comes time for us to look at the data. Joining allows us to retrieve data in a form that humans can easily read from two or more tables that are connected by a relationship. In this lesson, we'll look at the join process conceptually."

### Learning Outcomes

By the end of this lesson, the learner will be able to:

1. Compare and contrast inner and outer joins.
1. Compare and contrast left outer, right outer, and full outer joins.

---

## Inner Joins (10 min)

> The purpose of this section is to explain the concept and use of inner joins.

### About Inner Joins

* Joining is the process of retrieving data from two connected tables using a relationship, often joining a primary key to a foreign key. There are two main types: **inner join** and **outer join**.
* Inner joins are used when you can expect a value in both tables of the join. You’ll only see results when there is a matching value in both tables. If there isn’t a matching value in the second table, the row will not be shown. You’ll often see it represented by a Venn diagram like this (referring to the image in the slide). But that diagram isn't ideal as it suggests there will be a low percentage of matching values. It should look more like this!
* Most of the examples we’ve shown so far in our normalization would be joined using an inner join. We would expect every school to have a city, every home team to be in the team table, and every advantage card number to appear in the advantage card table.
* What happens if you associate a receipt to an advantage card that doesn’t exist, and then use an inner join to the card table? That receipt will not appear in the result set. 
 
---

## Outer Joins (10 min)

> The purpose of this section is to explain the concept and use of outer joins.

### About Outer Joins
* **Outer joins** are used when rows aren’t expected in both tables of a join.  Think about our video store.
    * If we were joining videos to rentals, can we be sure that every video has been rented?
    * What if a video is terribly unpopular or is brand new and just arrived? 
    * If we did an inner join from video to rental, we may not see every video in the store as those that have never been rented would disappear from our result set. If we want to see every video whether it has been rented or not, we use an **outer join**.
    
### The Three Flavors of Outer Joins
* **Left outer join** includes every row in the first table and only values from the second when a match is found. 
* **Right outer join** is the opposite of a left outer join. 
* **Full outer join** shows all rows from both tables whether or not they have matching rows in an opposite table. 

### More About Outer Joins
* You’ll use left outer join a lot. There will be orders without invoices, invoices without payments, cstomers without email addresses, and so on.
* I almost never use right join. If I see a chance to do a right join, I typically flip the table order and call it a left join. 
* Full outer joins are rarely used.
 
---

## We Do: Practicing Joins (20 min)
![code-along][code-along]

> The purpose of this activity is to give learners some practice joining data from a data model and exploring what it's like to work with normalized relational data.

1. Present the class with a printout of sample video store rows. Then ask them to identify primary keys and foreign keys.  
1. Note that the CustomerID columns are the same in both tables. Note that the VideoID and MovieID are NOT. This is absolutely allowed, although some consider it bad form.
1. What tables and what join type would be used to answer these questions? Use the SQL database to show it live, if desired.
1. What movies have never been rented?
1. What customers most recently rented a movie?
1. What customers from the 268 area code have rented an R-rated movie?
1. Have the class think of more questions they could ask this data set.

## Recap (10 min)
![take note icon][take-note]

* Joins are the flipside to normalization.
* Joining allows us to combine data from two or more tables that have relationships so that it is easier for humans to read.
* There are two main kinds of joins: inner and outer.

Learners should now be able to:

* Compare and contrast inner and outer joins.
* Compare and contrast left outer, right outer, and full outer joins.

---
© 2019 Trilogy Education Services

[present]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-present/res/mipmap-hdpi/icon-present.png "Present"

[discuss]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-discuss/res/mipmap-hdpi/icon-discuss.png "Discuss"

[take-note]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-take-note/res/mipmap-hdpi/icon-take-note.png "Take Note"

[show-code]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-show-code/res/mipmap-hdpi/icon-show-code.png "Show Code"

[code-along]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-code-along/res/mipmap-hdpi/icon-code-along.png "Code Along"

[starter-code]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-starter-code/res/mipmap-hdpi/icon-starter-code.png "Starter Code"

[kata]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-kata/res/mipmap-hdpi/icon-kata.png "Kata"

[time]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-time/res/mipmap-hdpi/icon-time.png "Time"

[warning]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-warning/res/mipmap-hdpi/icon-warning.png "Warning"

[break]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-break/res/mipmap-hdpi/icon-break.png "Break"

[alert]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-alert/res/mipmap-hdpi/icon-alert.png

[need-code]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/need-code-300.png

[need-content]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/need-content-300.png


