# Requirements

Write a Java program that calculates and displays the mortgage payment amount given the following:

- The amount of the mortgage
- The term of the mortgage
- The interest rate of the mortgage

---
© 2019 Trilogy Education Services
