# Lesson Overview: Spring Data JPA
This lesson is an introduction to using Spring Data JPA to build Java DAOs.

## Topics
* Repositories
* Model annotations
* Database configuration
* Simple unit tests

## Assessments
* Car Lot JPA DAO
* Coffee Inventory JPA DAO

## Required Software and Resources
* Java 8
* IntelliJ
* MySQL
* MySQL Workbench 

## Approach
This lesson builds on the learners' knowledge of SQL, relational databases, Java, and Java DAOs. The material steps through how to implement a DAO with Spring Data JPA beginning with the concept of a repository and ending with a set of simple unit tests to verify the implementation. 

## Assumptions
* Understanding of basic SQL (insert, select, update, delete, join)
* Undertanding of primary and foreign keys
* Ability to use MySQL and MySQL workbench to create schemas and execute SQL scripts
* Understanding of the Java language
* Ability to create and run Spring Boot projects using Spring Initializr
* Understanding of Maven project structure and dependency management
* Ability to use Java annotations
* Experience implementing Java DAOs with either JDBC or Spring JdbcTemplates
* Ability to create unit/integration tests with Junit
* Ability to use dependency injection to autowire components into JUnit tests

---

© 2019 Trilogy Education Services
