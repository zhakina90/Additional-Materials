package com.company;

public class FormattedOutput {

    public static void main(String[] args) {

        System.out.format("My name is %s and I am %d years old", "Timothy", 34);
    }
}
