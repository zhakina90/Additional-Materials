package com.company;

public class WordList {

    public static void main(String[] args) {

        String[] wordList = {"byte", "case", "catch", "class", "const", "continue", "do", "double", "else", "extends"};

        for(String element : wordList) {
            System.out.println(element);
        }


    }

}
