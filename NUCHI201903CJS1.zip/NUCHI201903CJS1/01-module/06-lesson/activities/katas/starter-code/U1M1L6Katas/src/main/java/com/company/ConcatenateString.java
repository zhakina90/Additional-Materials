package com.company;

public class ConcatenateString {

    public static void main(String[] args) {

        // Do the following with the following String array:
        //
        // * Print each element to the screen
        // * Create a new String that consists of the concatenation of all elements in the array
        // * Print the new string

        String[] strings = {"foo", "bar", "baz",
                            "Java", "C#", "C++",
                            "Python", "C", "JavaScript",
                            "Apple", "Dell", "Lenovo"};


    }
}
