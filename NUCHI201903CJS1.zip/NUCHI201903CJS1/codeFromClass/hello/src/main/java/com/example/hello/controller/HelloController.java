package com.example.hello.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
public class HelloController {

    @RequestMapping(value="/springhassprung", method= RequestMethod.GET)
    String sayHello() {
        return "hello";
    }

    @RequestMapping(value="/whattimeisit", method= RequestMethod.GET)
    String getTime() {
        Date myDate = new Date();
        return myDate.toString();
    }

    @RequestMapping(value="/echo/{myVar}", method= RequestMethod.GET)
    int getTime(@PathVariable int myVar) {
        Date myDate = new Date();
        return myVar;
    }

    @RequestMapping(value="/hello/{thePersonToGreet}", method= RequestMethod.GET)
    String sayHello(@PathVariable String thePersonToGreet) {
        return "Hello, " + thePersonToGreet;
    }

    // localhost:8080/whattimeisit
}
