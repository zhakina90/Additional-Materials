package com.example.echorangeservice.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
public class ERSController {

    @RequestMapping(value = "/echo/{thingToEcho}", method= RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public int userInt(@PathVariable int thingToEcho) {
        if (thingToEcho < 1 || thingToEcho > 10) {
            throw new IllegalArgumentException("Input must be between 1 and 10.");
        }

        return thingToEcho;
    }
}
