package com.company;

import java.util.Scanner;

public class MarvelMovieRank {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String captainAmericaRank = "";
        String thorRank = "";
        String ironManRank = "";
        String avengersRank = "";
        String guardiansRank = "";

        System.out.println("Please give a ranking from 1 to 5 for each of the following movies:");
        System.out.println("Captain America");
        captainAmericaRank = scanner.nextLine();
        System.out.println("Thor");
        thorRank = scanner.nextLine();
        System.out.println("Iron Man");
        ironManRank = scanner.nextLine();
        System.out.println("The Avengers");
        avengersRank = scanner.nextLine();
        System.out.println("Guardians of the Galaxy");
        guardiansRank = scanner.nextLine();

        System.out.println("Your rankings are:");
        System.out.println("Captain America: " + captainAmericaRank);
        System.out.println("Thor: " + thorRank);
        System.out.println("Iron Man: " + ironManRank);
        System.out.println("The Avengers: " + avengersRank);
        System.out.println("Guardians of the Galaxy: " + guardiansRank);

    }
}
