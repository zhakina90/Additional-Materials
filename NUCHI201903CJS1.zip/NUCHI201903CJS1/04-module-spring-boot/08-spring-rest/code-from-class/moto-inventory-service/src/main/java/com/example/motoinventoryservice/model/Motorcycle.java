package com.example.motoinventoryservice.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Motorcycle {

    private int id;
    @NotEmpty(message = "You must supply a value for VIN.")
    @Size(min = 5, max = 12, message = "vin must be between 5 and 12 characters, inclusive")
    private String vin;
    @NotEmpty(message = "You must supply a value for make.")
    private String make;
    @NotEmpty(message = "You must supply a value for model.")
    private String model;
//    @NotEmpty(message = "You must supply a value for year.")
//    @Size(min = 4, max = 4, message =  "Year must be 4 digits.")
    private int year;
    //@NotEmpty(message = "You must supply a value for color.")
    @NotNull(message = "Color must not be null")
    private String color;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
