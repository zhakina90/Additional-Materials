# Coding Bat

* Do the first 15 Lists-1 exercises on Coding Bat

---
© 2019 Trilogy Education Services