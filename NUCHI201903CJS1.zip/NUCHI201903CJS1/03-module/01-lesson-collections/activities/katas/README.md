# Katas

## Specifications

For all of the below, remember to program to the interface rather than to the concrete class (i.e., declare your variables as `List` instead of `ArrayList`).

1. Using the starter code provided, refactor the following array activities to use an `ArrayList` instead: 
    - `Total`
    - `WordList`
    - `SwapAndPrint`
    - `ReverseAndPrint`
1. In a new file for each, refactor the above activities to implement a `LinkedList` instead of an `ArrayList`.
1. Complete the following steps to create a `List` to hold information about your classmates.
    1. Create a `Classmate` class, which has the properties `name` and `hairColor`.
    1. Create a new `List` to hold `Classmate` objects.
    1. Add at least 5 `Classmate` objects to the list.
    1. Print out the name and hair color for every object in the list.
1. In a file called `PrintSet`, implement a `HashSet` and add these values to it: `5,1,2,1,4,1,5`. Use an `Iterator` to print all members of the `HashSet`. 

---
© 2019 Trilogy Education Services
 