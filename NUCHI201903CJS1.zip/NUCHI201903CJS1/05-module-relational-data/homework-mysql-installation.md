# MySQL Installation

This homework assignment requires that you install MySQL database on your laptop.

1. Download MySQL Community Server https://dev.mysql.com/downloads/mysql/
1. Choose the latest version for your platform.
1. Follow the installation instructions for your platform:
    * Windows (use the installer for the community release): https://dev.mysql.com/doc/refman/8.0/en/windows-installation.html
    * Mac OS (use the Native Package): https://dev.mysql.com/doc/refman/8.0/en/osx-installation.html
1. Follow the prompts and use the default installation locations and default port numbers.
1. When it asks for a username and password use:
    * username: root
    * password: root

---

© 2019 Trilogy Education Services





