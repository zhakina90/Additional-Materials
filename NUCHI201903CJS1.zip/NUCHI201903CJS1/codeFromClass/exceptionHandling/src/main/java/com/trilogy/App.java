package com.trilogy;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.util.Scanner;

public class App {
    public static void main (String[] args) throws IOException{

        try {
            myOtherMethod();
        } catch (Exception ex) {
            System.out.println("myOtherMethod on the line above threw this exception " + ex.getClass() + " " + ex.getMessage());
        }
        System.out.println("We are continuing");
        try {
            // new FileWriter will throw an exception if it can't open the file in the argument
            // for example, if you pass "/burp/cough/slash/filename" and that path does not exist
            // the FileWriter constructor will throw an exception
            PrintWriter writer = new PrintWriter(new FileWriter("thisFilename.yes"));

            writer.println("File line 1");
            writer.println("File line 2");

            writer.flush();
            writer.close();
            // you can catch multiple types of exceptions - this is treated like an if/else loop
            // if the exception is of type ArrayIndexOutOfBoundsException
        } catch (ArrayIndexOutOfBoundsException aioobException) {
            System.out.println("Somehow we got an array index out of bounds exception: " + aioobException.getMessage());
        } catch (IOException myFirstHandledException) {
            System.out.println("An error occurred: " + myFirstHandledException.getMessage());
        } catch (Exception exception) {
            System.out.println("Caught a different exception: " + exception.getClass());

        // A finally block ALWAYS EXECUTES. finally is OPTIONAL.
        } finally {
            System.out.println("Running the finally block.");
        }

        // If the exceptions above this line are not handled, this line will not print.
        System.out.println("Doing other things!");
    }

    /**
     * myOtherMethod does not handle an exception. parseInt could THROW an exception
     * which can either be handled by the calling method (in this case main), or
     * not handled by main, in which case the program will exit/fail/quit with that exception
     */
    public static void myOtherMethod() {
        Scanner scanner = new Scanner(System.in);

        String userInput;
        int number;

        //a do/while loop that asks for a number
        do {
            System.out.println("Please enter a number between 1 and 10");
            userInput = scanner.nextLine();
            number = Integer.parseInt(userInput);
        } while (number < 1 || number > 10);

        System.out.println("Thanks for playing - you chose: " + number);
    }

    /**
     * myMethod uses a do/while loop to ask for user input and handles the exception within the loop
     */
    public static void myMethod() {
        Scanner scanner = new Scanner(System.in);

        String userInput;
        int number;

        do {
            System.out.println("Please enter a number between 1 and 10");
            userInput = scanner.nextLine();
            try {
                number = Integer.parseInt(userInput);
            } catch (NumberFormatException nfe) {
                System.out.println("Please enter a number. Not a non-number. What's your problem? Fam. ?");
                number = 0;
            }
        } while (number < 1 || number > 10);

        System.out.println("Thanks for playing - you chose: " + number);
    }
}
