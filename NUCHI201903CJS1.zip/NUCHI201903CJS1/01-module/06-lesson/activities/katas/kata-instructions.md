## List of Katas

You will be given starter code in a project called U1M1L6Katas. Each of the kata specs below has a corresponding Java class containing starter code and a repeat of these directions. Complete these katas using the starter code.

**NOTE**: All code and calculations should be done manually; do not use helper libraries to find these answers!

1. **Total**: Write code that finds the sum of all the values in an array of ints. Your code should work for an array of any size.
1. **Total Odd**: Write code that finds the sum of all the values of the odd numbered indexes in an array of ints. Your code should work for an array of any size.
1. **Total Even**: Write code that finds the sum of all the values of the even numbered indexes in an array of ints. Your code should work for an array of any size.
1. **2nd Largest Number**: Write code that finds the second largest number in an array of ints. Print out both the value and its associated index. Your code should work for an array of any size.
1. **Less Than 5**: Write code that goes through an array of ints and prints out all values less than 5 and their associated index values. 
1. **Swap and Print**: Write code that does the following with an array of ints. Your code should work for an array of any size.
    1. Print the original array.
    1. Swap the first and last elements.
    1. Print the new array.
1. **Reverse and Print**: Write code that does the following with an array of ints. Your code should work for an array of any size.
    1. Print the original array.
    1. Reverse the array.
    1. Print the new array.
1. **Concatenate String**: Write code that does the following with an array of Strings:
    1. Print each element to the screen.
    1. Create a new String that consists of the concatenation of all elements in the array.
    1. Print the new string.
1. **Word List**: Create and initialize two arrays of Strings in two different ways and print the values in the arrays to the screen. You will be given a list of words to use as values in your arrays.
1. **Evens and Odds**: Given a 12-element String array, create two 6-element String arrays. Put the values of the even indices in one array and the values of the odd indices in the other.
1. **Split at 5**: Write code that does the following with an array of ints. Your code should work for an array of any size.
    1. Determine how many values are less than 5.
    1. Create two new arrays. One will hold the values under 5 and the other will hold the values over 5.
    1. Copy all the values under 5 to one array and the values over 5 to the other array.
    1. Print all three arrays to the screen.
1. **Print Reverse**: Write code that prints the elements of an array of ints to the screen in reverse order. This code should work for any size array.
1. **Print Every 3rd**: Write code that goes through an array of ints and prints every third element to the screen. This code should work for any size array.


---
© 2019 Trilogy Education Services