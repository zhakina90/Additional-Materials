import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MyMap {
    public static void main(String[] args) {
        //doMovies();
        //doHeights();
        doDesserts();
    }

    public static void doDesserts() {
        Map<String, String> desserts = new HashMap<>();

        desserts.put("Cheesecake Factory", "Cheesecake");
        desserts.put("McDonalds", "McFlurry");
        desserts.put("Chili's", "Molten Chocolate Cake");

        Set<Map.Entry<String, String>> myEntries = desserts.entrySet();
        for (Map.Entry<String, String> entry : myEntries) {
            System.out.println("Key = " + entry.getKey() + "; Value = " + entry.getValue());
        }

        System.out.println("----------------- Setting McDonald's best dessert to null");
        desserts.put("McDonalds", null);
        myEntries = desserts.entrySet();
        for (Map.Entry<String, String> entry : myEntries) {
            System.out.println("Key = " + entry.getKey() + "; Value = " + entry.getValue());
        }

        System.out.println("----------------- Removing Cheesecake Factory");
        desserts.remove("Cheesecake Factory");
        myEntries = desserts.entrySet();
        for (Map.Entry<String, String> entry : myEntries) {
            System.out.println("Key = " + entry.getKey() + "; Value = " + entry.getValue());
        }

        System.out.println("----------------- Adding a null key");
        desserts.put(null, "coconut anything");
        myEntries = desserts.entrySet();
        for (Map.Entry<String, String> entry : myEntries) {
            System.out.println("Key = " + entry.getKey() + "; Value = " + entry.getValue());
        }


    }

    public static void doMovies() {
        //initialize
        //instantiate
        Map<String, String> favoriteMovies = new HashMap<>();

        //populate
        favoriteMovies.put("Ben", "This is the End");
        favoriteMovies.put("Aaron", "Black Dynamite");
        favoriteMovies.put("Zhamal", "Avengers");
        favoriteMovies.put("Dan", "Vacation");
        favoriteMovies.put("Sophonie", "Gladiator");

        //print values from
        String bensFavoriteMovie = favoriteMovies.get("Ben");
        System.out.println("Ben's favorite movie is " + bensFavoriteMovie);
        favoriteMovies.put("Dan", "It's a Wonderful Life");

        System.out.println("Dan's favorite movie is now " + favoriteMovies.get("Dan"));
        System.out.println("Ramya's favorite movie is " + favoriteMovies.get("Ramya"));
        System.out.println("Everything is OK.");

        Set<String> myKeys = favoriteMovies.keySet();
        for (String key: myKeys) {
            System.out.println("Here is a key in the favoriteMovies map: " + key);
        }

        System.out.println("---------------------- Removing Dan from the map");
        favoriteMovies.remove("Dan");
        myKeys = favoriteMovies.keySet();
        for (String key: myKeys) {
            System.out.println("Here is a key in the favoriteMovies map: " + key);
        }


        favoriteMovies.replace("Ben", null);
        System.out.println("---------------------- Replacing Ben's favorite movie with null");
        myKeys = favoriteMovies.keySet();
        for (String key: myKeys) {
            System.out.println("Here is a key in the favoriteMovies map: " + key);
        }

        Collection<String> allTheMovieValues = favoriteMovies.values();
        for (String theMovie : allTheMovieValues) {
            System.out.println("This movie is someone's favorite: " + theMovie);
        }

        //print all key-value pairs
        for(String keyValue : favoriteMovies.keySet()) {
            System.out.println("Key: " + keyValue + ", Value: " + favoriteMovies.get(keyValue));
        }

    }

    public static void doHeights() {
        Map<String, Integer> heights = new HashMap<>();

        //Creating map entries
        heights.put("Joe",72);
        heights.put("Erin", 63);
        heights.put("Sally", 65);

        System.out.println("Number of entries in the map: " + heights.size());

        // Get Joe's height
        int joesHeight = heights.get("Joe");
        System.out.println("Joe's height is " + joesHeight);

        // Update Joe's height using replace
        heights.replace("Joe", 74);
        joesHeight = heights.get("Joe");
        System.out.println("Joe is "  + joesHeight + " inches tall.");

        // Update Joe's height with put
        heights.put("Joe", 76);
        joesHeight = heights.get("Joe");
        System.out.println("Joe is "  + joesHeight + " inches tall.");
    }
}
