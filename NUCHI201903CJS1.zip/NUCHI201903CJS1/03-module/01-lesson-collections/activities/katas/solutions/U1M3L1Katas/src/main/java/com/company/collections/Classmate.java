package com.company.collections;

public class Classmate {
    private String name;
    private String hairColor;

    public Classmate(String name, String hairColor) {
        this.name = name;
        this.hairColor = hairColor;
    }

    public String getName() {
        return name;
    }

    public String getHairColor() {
        return hairColor;
    }
}
