package com.trilogy;

import java.util.ArrayList;
import java.util.List;

public class EmployeeMain {
    public static void main(String[] args) {
        List<Employee> employeeList = new ArrayList<>();

        Employee doug = new Employee("Doug", "developer");
        Employee lois = new Employee("Lois", "boss");

        employeeList.add(doug);   //0
        employeeList.add(lois);   //1
        employeeList.add(new Employee ("Beth", "CTO")); //2

        for (Employee thisEmployee : employeeList) {
            System.out.println(thisEmployee);
        }

        doug.setDepartment("senior developer");

        for (Employee thisEmployee : employeeList) {
            System.out.println(thisEmployee);
        }

        Employee tempEmployee = employeeList.get(1);
        tempEmployee.setName("Alex");

        for (Employee thisEmployee : employeeList) {
            System.out.println(thisEmployee);
        }

        System.out.println("DRUM ROLL PLEASE....");
        try {Thread.sleep(3000);}
        catch(Exception ex) {
            System.out.println("This didn't happen.");
        }
        System.out.println(lois.getName());

    }
}
