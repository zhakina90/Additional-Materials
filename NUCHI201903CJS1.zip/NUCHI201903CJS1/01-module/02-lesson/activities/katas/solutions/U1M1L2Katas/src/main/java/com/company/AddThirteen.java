package com.company;
import java.util.Scanner;

public class AddThirteen {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = Integer.parseInt(scan.nextLine());

        System.out.format("%d + 13 is %d", num, num + 13);
    }
}
