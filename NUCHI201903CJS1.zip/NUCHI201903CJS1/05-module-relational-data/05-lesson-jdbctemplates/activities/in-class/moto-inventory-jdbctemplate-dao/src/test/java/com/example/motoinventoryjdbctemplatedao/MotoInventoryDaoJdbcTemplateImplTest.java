package com.example.motoinventoryjdbctemplatedao;

import com.example.motoinventoryjdbctemplatedao.domain.Motorcycle;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runner.notification.RunListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class MotoInventoryDaoJdbcTemplateImplTest {

    @Autowired
    protected MotoInventoryDao dao;

    @Before
    public void setUp() throws Exception {
        List<Motorcycle> allMotorcycles = dao.getAllMotorcycles();

        allMotorcycles.stream()
                .forEach(motorcycle -> dao.deleteMotorcycle(motorcycle.getId()));
    }

    @Test
    public void addGetDeleteMotorcycle() {
        Motorcycle motorcycle = new Motorcycle();
        motorcycle.setMake("Ducati");
        motorcycle.setModel("Panigale");
        motorcycle.setVin("5599559");
        motorcycle.setYear("2018");
        motorcycle.setColor("black");

        motorcycle = dao.addMotorcycle(motorcycle);

        Motorcycle motorcycle2 = dao.getMotorcycle(motorcycle.getId());

        assertEquals(motorcycle, motorcycle2);

        dao.deleteMotorcycle(motorcycle.getId());

        motorcycle2 = dao.getMotorcycle(motorcycle.getId());

        assertNull(motorcycle2);
    }

    @Test
    public void getAllMotorcycles() {
        Motorcycle motorcycle = new Motorcycle();
        motorcycle.setMake("Ducati");
        motorcycle.setModel("Panigale");
        motorcycle.setVin("5599559");
        motorcycle.setYear("2018");
        motorcycle.setColor("black");

        motorcycle = dao.addMotorcycle(motorcycle);

        motorcycle = new Motorcycle();
        motorcycle.setMake("Yugo");
        motorcycle.setModel("Faster");
        motorcycle.setVin("5599560");
        motorcycle.setYear("1994");
        motorcycle.setColor("green");

        motorcycle = dao.addMotorcycle(motorcycle);

        List<Motorcycle> motos = dao.getAllMotorcycles();

        assertEquals(motos.size(), 2);
    }

    @Test
    public void getMotorcyclesByMake() {
        Motorcycle motorcycle = new Motorcycle();
        motorcycle.setMake("Ducati");
        motorcycle.setModel("Panigale");
        motorcycle.setVin("5599559");
        motorcycle.setYear("2018");
        motorcycle.setColor("black");

        motorcycle = dao.addMotorcycle(motorcycle);

        motorcycle = new Motorcycle();
        motorcycle.setMake("Yugo");
        motorcycle.setModel("Faster");
        motorcycle.setVin("5599560");
        motorcycle.setYear("1994");
        motorcycle.setColor("green");

        motorcycle = dao.addMotorcycle(motorcycle);

        motorcycle = new Motorcycle();
        motorcycle.setMake("Yugo");
        motorcycle.setModel("Slower");
        motorcycle.setVin("559950");
        motorcycle.setYear("1998");
        motorcycle.setColor("orange");

        motorcycle = dao.addMotorcycle(motorcycle);

        List<Motorcycle> motos = dao.getMotorcycleByMake("Yugo");
        assertEquals(motos.size(), 2);

        motos = dao.getMotorcycleByMake("Ducati");
        assertEquals(motos.size(), 1);

        motos = dao.getMotorcycleByMake("Honda");
        assertEquals(motos.size(), 0);



    }

    @Test
    public void updateMotorcycle() {
        Motorcycle motorcycle = new Motorcycle();
        motorcycle.setMake("Ducati");
        motorcycle.setModel("Panigale");
        motorcycle.setVin("5599559");
        motorcycle.setYear("2018");
        motorcycle.setColor("black");

        motorcycle = dao.addMotorcycle(motorcycle);

        motorcycle.setColor("white");
        motorcycle.setYear("2021");

        dao.updateMotorcycle(motorcycle);

        Motorcycle updatedMotorcycle = dao.getMotorcycle(motorcycle.getId());

        assertEquals(updatedMotorcycle, motorcycle);
    }
}