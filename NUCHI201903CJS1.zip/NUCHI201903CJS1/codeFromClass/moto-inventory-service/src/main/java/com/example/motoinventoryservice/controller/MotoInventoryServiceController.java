package com.example.motoinventoryservice.controller;

import com.example.motoinventoryservice.model.Motorcycle;
import org.springframework.http.HttpStatus;
import org.springframework.web.HttpSessionRequiredException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;

@RestController
public class MotoInventoryServiceController {
    @RequestMapping(value = "/motorcycles", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.CREATED)
    public Motorcycle createMotorcycle(@RequestBody @Valid Motorcycle motorcycle) {
        Random rnd = new Random();

        motorcycle.setId(rnd.nextInt(9999));

        return motorcycle;
    }
    @RequestMapping(value = "/repeater/{stringToRepeat}/{numberOfTimes}", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.CREATED)
    public String repeatSomeWords(@PathVariable String stringToRepeat, @PathVariable int numberOfTimes) {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < numberOfTimes; i = i + 1) {
            sb.append((i+1) + "." + stringToRepeat + "<br />");
        }
        return sb.toString();
    }
    @RequestMapping(value = "/countdown/{toWhat}/{daysLeft}", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.CREATED)
    public String countdown(@PathVariable String toWhat,
                            @PathVariable int daysLeft,
                            @RequestParam(defaultValue="true", required=false) boolean includeWeekend) {
        Calendar cal = new GregorianCalendar();
        StringBuffer sb = new StringBuffer();
        DateFormat df = new SimpleDateFormat("EEEE, MMMM d");

        for (int i = daysLeft; i > 0; i--) {
            if (includeWeekend == false) {
                while (cal.get(Calendar.DAY_OF_WEEK) == 1 || cal.get(Calendar.DAY_OF_WEEK) == 7) {
                    cal.add(Calendar.DATE, 1);
                }
            }
            sb.append("It's " + df.format(cal.getTime()) + "! There ");
            if (i > 1) {
                sb.append("are " + i + " days of " + toWhat + " left!");
            } else {
                sb.append("is 1 day of " + toWhat + " left!");
            }
            sb.append("<br />");
            sb.append("<br />");
            cal.add(Calendar.DATE, 1);
        }

        sb.append("It's the end of " + toWhat + "!!!!!<br />");

        return sb.toString();
    }
    @RequestMapping(value = "/countdown/{start}/{end}/{event}", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.CREATED)
    public String startEndEvent(@PathVariable String start,
                            @PathVariable String end,
                            @PathVariable String event,
                            @RequestParam(defaultValue="It's over!", required=false) String message) {
        Calendar cal = new GregorianCalendar();
        StringBuffer sb = new StringBuffer();
        DateFormat df = new SimpleDateFormat("EEEE, MMMM d");
        DateFormat inputDateFormat = new SimpleDateFormat("yyyyMMdd");

        try {
            Calendar startCal = new GregorianCalendar();
            startCal.setTime(inputDateFormat.parse(start));
            Calendar endCal = new GregorianCalendar();
            endCal.setTime(inputDateFormat.parse(end));

            int numberOfDaysLeft = (int) ((endCal.getTime().getTime() - startCal.getTime().getTime())/(24*60*60*1000));
            while (numberOfDaysLeft > 0) {
                sb.append("It's " + df.format(startCal.getTime()) + ". There ");
                if (numberOfDaysLeft > 1) {
                    sb.append("are " + numberOfDaysLeft + " days ");
                } else {
                    sb.append("is 1 day ");
                }
                sb.append("left of " + event + ".<br />");
                numberOfDaysLeft--;
                startCal.add(Calendar.DATE, 1);
            }
            sb.append("<br />");
            sb.append("It's " + df.format(startCal.getTime()) +". " + message);
        } catch (ParseException pe) {
            sb.append("You passed in a bad date");
        }
        return sb.toString();
    }

}

