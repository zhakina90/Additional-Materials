package com.example.motoinventoryjdbctemplatedao.controller;

import com.example.motoinventoryjdbctemplatedao.MotoInventoryDao;
import com.example.motoinventoryjdbctemplatedao.domain.Motorcycle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Random;


@RestController
@CrossOrigin
public class MotoInventoryJdbcController {

    @Autowired
    MotoInventoryDao dao;

    @RequestMapping(value = "/motorcycles", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.CREATED)
    public Motorcycle createMotorcycle(@RequestBody Motorcycle motorcycle) {
        //We're skipping the service layer! Today! June 7, 2019!

        return dao.addMotorcycle(motorcycle);
    }

}
