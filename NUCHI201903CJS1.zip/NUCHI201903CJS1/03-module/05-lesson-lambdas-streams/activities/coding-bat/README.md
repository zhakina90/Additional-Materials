# Coding Bat

1. On [Coding Bat](https://codingbat.com/java), complete the first 15 exercises under **String-1** (this means the first 5 rows, from helloName to middleTwo).



---
© 2019 Trilogy Education Services