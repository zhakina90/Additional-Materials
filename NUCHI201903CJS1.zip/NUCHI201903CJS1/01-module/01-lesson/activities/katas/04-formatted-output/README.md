# Formatted Output

## Instruction

So far, we've used `println` to print text to our standard output (`System.out`). Java also provides a method called `format`, which can be used to format our output to convert numbers to text for easier outputting. We'll delve into some of these concepts further in the next lesson, but for now, look over the basics below.

The following code:

```java
System.out.format("The value of the float is %f, while the value of the integer is %d, and the string is %s", 4.23, 5, "cat"); 
```

Will have the output:

```
The value of the float is 4.230000, while the value of the integer is 5, and the string is cat
```

Take a second to read through the code and try to understand how each piece of the puzzle comes together to form that output.

Important features to note:

* `%f` specifies that the value is a `float`. Simply put, this is a number that includes values after the decimal point.
* `%d` specifies that the value is an `integer`. This is a whole number.
* `%s` specifies that the value is a `string`. Strings are simply text, denoted by the double-quotes surrounding it.

Again, we'll cover all of this in more detail during the next lesson, but a core piece of being a developer is being able to extrapolate from a given pattern. 

It may seem like a little bit of a reach, but you've got this!

## Requirements

1. Create a new IntelliJ project called FormattedOutput following the same steps you took to create HelloWorld.
1. Add code to your main method that produces output similar to the following, using `System.out.format`, the appropriate format specifier, and value for both your name and age:

```
My name is <YOUR NAME> and I am <YOUR AGE> years old.
```

---
© 2019 Trilogy Education Services