package com.company;

public class WordList {

    public static void main(String[] args) {

        // Create and initialize two arrays of Strings in two different ways
        // and print the values in the array to the screen. Use the word list
        // below to initialize your arrays.

        // byte case catch class const continue do double else extends
        // final finally for while if transient goto throw throws class

        String[] arr1 = {"byte", "case", "catch", "class", "const", "continue", "do", "double", "else", "extends"};

        String[] arr2 = new String[10];

        arr2[0] = "final"; 
        arr2[1] = "finally"; 
        arr2[2] = "for"; 
        arr2[3] = "while"; 
        arr2[4] = "if"; 
        arr2[5] = "transient"; 
        arr2[6] = "goto"; 
        arr2[7] = "throw"; 
        arr2[8] = "throws"; 
        arr2[9] = "class";

        System.out.println("----------------");
        System.out.println("First Array");

        for(String element : arr1) {
            System.out.println(element);
        }

        System.out.println("----------------");
        System.out.println("Second Array");

        for(String element : arr2) {
            System.out.println(element);
        }

    }

}
