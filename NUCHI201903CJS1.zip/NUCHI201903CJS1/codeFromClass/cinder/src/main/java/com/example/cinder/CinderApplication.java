package com.example.cinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinderApplication.class, args);
	}

}
