# Coding Bat

1. On the [Coding Bat website](https://codingbat.com/java), complete the first 15 exercises in **Logic-1** (this means the rows 4-6, from more20 to fizzString2).



---
© 2019 Trilogy Education Services