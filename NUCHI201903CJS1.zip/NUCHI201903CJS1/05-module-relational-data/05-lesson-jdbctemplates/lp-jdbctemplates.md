# Lesson Plan: JdbcTemplates

Open the [slidedeck](https://docs.google.com/presentation/d/1Rz9U82YJhjMIj6G8ZuPxg6OtYvlj1kKJki404T4y0Yg/edit?usp=sharing) for this lesson.

## Level Set (5 min)
> Set the context, establish authenticity, and generate interest in the lesson's topic. Communicate why this content is important to the learner. 

> Open and project the Learning Outcomes slide while you present the lesson purpose.

### Purpose
![discuss][discuss]
> The purpose of this lesson is to show learners how to combine SQL and Java to build software components that can map data from Java objects into a relational database and manipulate that data. This lesson =also shows learners how to use TDD and Red/Green/Refactor to develop these components.


### Narrative

"Enterprise applications are driven by data, and most of that data is stored in relational databases. A Java application that can't interact with that data is useless. All database management systems have features that allow us to run SQL queries against our data, but that is of limited use in an enterprise setting. We don't want to be forced to enter all of the data into our database manually!"

"The solution to this is to automate the process by creating software that translates between Java and relational data. That is what this lesson is all about."

"JdbcTemplate is a class supplied by Spring that makes manipulating relational data easier."

### Learning Outcomes

By the end of this lesson, the learner will be able to:

1. Create a Spring Boot project with database support.
1. Create data transfer objects (DTOs) based on an existing database schema.
1. Design a Java DAO interface that supports the ability to create, read, update, and delete DTO data.
1. Use the TDD approach to create unit/integration tests for a Java DAO interface.
1. Configure a Spring Boot project to connect with a MySQL database.
1. Create prepared statement SQL strings that support the ability to create, read, update, and delete DTO data.
1. Use prepared statement strings and the JdbcTemplate ```update``` method to create new database entries for DTO data.
1. Use prepared statement string and the JdbcTemplate ```update``` method to update existing database entries for DTO data.
1. Use prepared statement strings and the JdbcTemplate ```queryForObject``` method to retrieve a database entries for DTO data.
1. Use prepared statement strings and the JdbcTemplate ```query``` method to retrieve multiple database entries for DTO data.
1. Create a method that maps a database entry into a DTO.

---

## Project Creation (5 min)

> The purpose of this section is to show learners which supporting libraries they need when creating projects that require JdbcTemplate and MySQL database support. This lesson assumes learners already know how to use Spring Initializr, so we are only showing them which starter dependencies to include.

### About Project Creation
Make the following points before the We Do:

* We'll be using the Spring Initializr to create projects with database support.
* Creating these projects is just like creating any other Spring Boot project—we are just adding some more starter dependencies.
* Specifically, we'll include ```web```, ```JDBC```, and ```MySQL``` support.
    * ```web``` support isn't stricly needed for the code we will write in this lesson, but the code that interacts with databases is generally build as part of a web application or web service. Including the ```web``` starter dependencies provides support for these web components.

---

## We Do: Create Spring Boot Project with Database Support
![code-along][code-along]

> The purpose is to show learners how to create a Spring Boot project with database support. We'll use this project in the We Do sections later in this lesson, so make sure everyone gets this done correctly.

1. Visit https://start.spring.io.
1. Enter the following in the form:
    * Group: com.company
    * Artifact: moto-inventory-jdbctemplate-dao
    * Dependencies:
        * Web
        * JDBC
        * MySQL
1. Click Generate Project.
1. Have learners download, save, and unzip the resulting project file.

---

## Data Transfer Object (DTO) Design (15 min)

> The purpose of this section is to show learners how to create DTOs based on existing database tables. This is pretty straightforward, but learners still need to be stepped through this process. The DTO will be based off the motorcycle table in the moto_inventory schema.

### About DTO Design
Make the following points before the We Do:

* When we have existing or pre-designed databases (as we do here), we must create our DTOs based on the tables in the database.
* This is a straightforward process:
    * Each table is represented by a class.
    * Each row in a table is a particular instance of the class.
    * The columns in the table are represented by properties of the class.
        * Column data types map to Java data types for the properties:
            * varchars -> String
            * int -> int or Integer
            * double -> double or Double
            * decimal -> BigInteger (we'll see this later in the lesson)
            * Data -> LocalDate (we'll see this later in the lesson)
    * DTOs have only properties and getters/setters.

---

## We Do: Create the DTO (30 min)
![code-along][code-along]

> The purpose is to show learners how to map a simple database table to a Java DTO. Make sure everyone gets this done because we will use the DTO in later We Dos.

1. Our DTO will be based on the following table. Discuss the following about the ```id``` column:

1. Notice that the ```id``` column is marked as:
    * ```not null```
    * ```auto_increment```
    * ```primary key```
1. From this, we can infer the following:
    * A value is required for this column.
    * The MySQL database will supply this value for us.
    * This value must be unique across all rows in this table.
1. Tell learners to keep this things in mind as they will affect the code we write later on.

```sql
create table if not exists motorcycle (
	id int not null auto_increment primary key,
    vin varchar(20) not null,
    make varchar(20) not null,
    model varchar(20) not null,
    year varchar(4) not null,
    color varchar(20) not null
);
```
This maps to a class called Motorcycle with the following properties:

```java
public class Motorcycle {

    private int id;
    private String vin;
    private String make;
    private String model;
    private String year;
    private String color;
}   
```

1. Have learners generate getters/setters for all properties.
1. Have learners generate equals and hashcode for this class using all the fields for both.
    * Equals and hashcode make testing our DAO much easier because we can easily tell if one Motorcycle object is equal to another one.

```java
public class Motorcycle {

    private int id;
    private String vin;
    private String make;
    private String model;
    private String year;
    private String color;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Motorcycle that = (Motorcycle) o;
        return getId() == that.getId() &&
                Objects.equals(getVin(), that.getVin()) &&
                Objects.equals(getMake(), that.getMake()) &&
                Objects.equals(getModel(), that.getModel()) &&
                Objects.equals(getYear(), that.getYear()) &&
                Objects.equals(getColor(), that.getColor());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getVin(), getMake(), getModel(), getYear(), getColor());
    }
}

```

---

## DAO Interface Design (15 min)

> The purpose of this section is to show learners the basic pattern of a DAO interface.

### About DAO Interface Design
Make the following points before the We Do:

* DAO interfaces follow a general pattern that has methods for creating, reading, updating, and deleting DTO data in the database.
* Some of the details can vary. Teams usually have some sort of naming convention or guide.
* Some implementations have more specialty methods for fetching DTOs by different criteria. This depends on the requirements of the project.
* Our naming convention is to name the interface as ```<Some Descriptor>Dao``` (e.g., ```MotoInventoryDao```).
* We name the implementing class ```<Name of Interface><Implementation Description>Impl``` (e.g., ```MotoInventoryJdbcTemplateImpl```).

---

## We Do: DAO Interface (15 min)
![code-along][code-along]

> The purpose of this We Do is to show learners how to create a basic DAO interface. We will use this DAO interface later in the lesson so make sure everyone completes this correctly.

1. Have learners create a new Java interface called ```com.company.motoinventoryjdbctemplatedao.dao.MotoInventoryDao```.
1. Create the following method definitions. Pointing out the following:
    * We use the ```id``` of the Motorcycle to get it from the database. More later on how that id is assigned.
    * When returning more than one Motorcycle we return a List.
    * The method that adds a Motorcycle entry to the database ```addMotorcycle``` returns a Motorcycle object. The returned object includes the id autogenerated by the database. Remind learners of the ```auto_increment``` specification on the table definition.
    * Neither the delete nor udpate methods return a value.
        * Update doesn't need to return a value like add does because we're updating an existing Motorcycle, which means we already have an id.
        * The delete method could return the deleted motorcycle, but we made a design choice not to do that.
    * We have one "specialty" get method that finds all the motorcycles made by a particular manufacturer.


```java
public interface MotoInventoryDao {

    Motorcycle getMotorcycle(int id);

    List<Motorcycle> getAllMotorcycles();

    Motorcycle addMotorcycle(Motorcycle motorcycle);

    void updateMotorcycle(Motorcycle motorcycle);

    void deleteMotorcycle(int id);

    List<Motorcycle> getMotorcyclesByMake(String make);

}
```

Now have learners create a new class called ```com.company.motoinventoryjdbctemplatedao.dao.MotoInventoryDaoJdbcTemplateImpl```.

1. Have them add code so that the new class implements ```MotoInventoryDao```.
1. Have them tell IntelliJ to generate code to implement the interface methods using the Code menu:
    * Code > Implement methods...
1. The class should look like this:

```java
@Repository
public class MotoInventoryDaoJdbcTemplateImpl implements MotoInventoryDao {

    @Override
    public Motorcycle getMotorcycle(int id) {

        return null;
    }

    @Override
    public List<Motorcycle> getAllMotorcycles() {

        return null;
    }

    @Override
    public List<Motorcycle> getMotorcyclesByMake(String make) {

        return null;
    }

    @Override
    @Transactional
    public Motorcycle addMotorcycle(Motorcycle motorcycle) {

        return null;
    }

    @Override
    public void updateMotorcycle(Motorcycle motorcycle) {
    }

    @Override
    public void deleteMotorcycle(int id) {
    }

}

```

---

## BREAK (10 min) 
![break icon][break] 

---

## TDD and Unit/Integration Tests (5 min)

> The purpose of this section is to show learners how to use TDD and Red/Green/Refactor to develop their DAOs. We show them how to implement all of their unit/intergration tests before they implement any of the code and then, later,  how to implement the code until all the unit tests pass. Introduce the section like this:

"We are going to introduce a concept called test-driven development (TDD) in this section. TDD uses a technique called Red Green Refactor. This technique involves implementing the shell of your code (as we did above) and then writing all the tests for the code. Obviously, these tests will fail (because we haven't implemented any of the logic). This is the "Red" part of Red Green Refactor. Next, you implement you code until all of the tests pass. This is the "Green" part of Red Green Refactor. Finally the team can feel confident in any refactoring they do moving forward because they have a robust set of unit tests that will tell them if they have broken anything during the refactoring."

## We Do: Create JUnit Test (10 min)
![code-along][code-along]

> The purpose of the We Do is to show the learner how to generate the shell of a unit test for a given interface or class.

Display your IDE as you step the group through generating the unit test shell for the MotoInventoryDao interface.

1. Have everyone open their Moto Inventory project.
1. Have everyone open the MotoInventoryDao interface file.
1. Have everyone put their cursors on the name of the interface and press Alt-Enter. This will display the Intention Menu.
1. Have everyone choose Create Test.
1. Have everyone check the setUp/@Before checkbox in the Generate section and the getMotorcycle checkbox in the "Generate test methods for" section. Leave everything else at their defaults.
1. Have everyone click OK to generate the test.

Everyone's code should look like this:

```java
public class MotoInventoryDaoJdbcTemplateImplTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void getMotorcycle() {
    }
}
```

---

## We Do: Inject DAO (10 min)
![code-along][code-along]

> Now we will show learners how to construct some basic unit/integration tests for their DAO code. Let them know that these tests are technically called integration tests because they involve the database, whereas unit tests involve just the component being tested. We are going to explain the units tests in terms of the AAA pattern of testing: Arrange Act Assert.
>
> The first step is to add annotations that allow us to auto-wire the DAO into our test and then to make sure the DAO is in a known good state before each test. This is part of the Arrange phase of testing.

Refer to the code block below and have the learners type along with you:

1. Add the ```@RunWith(SpringJUnit4ClassRunner.class)``` and ```@SpringBootTest``` annotations at the class level.
    * This enables us to ask Spring to hand us an instance of our DAO (we'll see that in the next step).
1. Add a declaration for a DAO class property.
    * This is a declaration only, Spring will hand us an instance of the DAO when our test class is created.
1. Add the ```@Autowired``` annotation right before the DAO declaration
    * This is the annotation that causes Spring to hand us an instance of our DAO
    * This is called **dependency injection**. Our test class *depends on* the DAO to get its job done. Rather than managing that dependency itself (by instantiating the DAO), it relies on the Spring framework to *inject* the DAO into our class.
1. Add code to the ```setUp``` method that deletes all motorcycles from the DAO.
    * This method gets run by the JUnit framework before each test method.
    * The ```@Before``` annotation is what tesll JUnit to run this method before each test. The name of the method is arbitrary; it is the annotation that causes this method to be run before each test.
    * We use this method to put the DAO in a known good state. The state we have chosen is an empty DAO. We remove all Motorcycles before each test.

```java
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class MotoInventoryDaoTest2 {

    @Autowired
    protected MotoInventoryDao dao;


    @Before
    public void setUp() throws Exception {
        // clean out the test db
        List<Motorcycle> mList = dao.getAllMotorcycles();

        mList.stream()
                .forEach(motorcycle -> dao.deleteMotorcycle(motorcycle.getId()));
    }

    @Test
    public void getMotorcycle() {
    }
}
```

## We Do: addGetDeleteMotorcycle Test (15 min)
![code-along][code-along]

> Now we will walk through the implementation of our first unit test. This will test adding a Motorcycle, getting that Motorcycle from the database, and deleting the Motorcycle from the database. This is convenient initial "smoke test" that shows basic functionality.

Refer to the code block below and have learners type along with you:

1. Change the name of the ```getMotorcycle``` method to ```addGetDeleteMotorcyle```
    * Note that the method name is arbitrary.
1. Point out the ```@Test``` annotation. This is what causes JUnit to recognize this method as a test and run it.
1. Implement the test:
    * Arrange:
        * Create a new Motorcycle.
    * Act:
        * Add the motorcycle to the DAO.
        * Retrieve the motorcycle from the DAO.
    * Assert:
        * Compare the original Motorcycle object with the one retrieved from the database. Make sure they are equal.
    * Act:
        * Delete the Motorcycle from the DAO.
        * Retrieve the Motorcycle from the DAO.
    * Assert:
        * Assert that the Motorcycle is null.
    
```java
    @Test
    public void addGetDeleteMotorcycle() {

        Motorcycle moto = new Motorcycle();
        moto.setVin("12345");
        moto.setMake("Honda");
        moto.setModel("Africa Twin");
        moto.setYear("2019");
        moto.setColor("black");

        moto = dao.addMotorcycle(moto);

        Motorcycle moto2 = dao.getMotorcycle(moto.getId());

        assertEquals(moto, moto2);

        dao.deleteMotorcycle(moto.getId());

        moto2 = dao.getMotorcycle(moto.getId());

        assertNull(moto2);
    }
```
---

## BREAK (10 min) 
![break icon][break] 

---

## You Do: Other Test Code (20 min)
![show-code][show-code]

> The purpose of the Instructor Do is let learners try their hand at the other test methods for the Moto Inventory DAO. Let them work in pairs for 20 minutes and then bring everyone together to go over the code. Learners do not need to complete all tests, we will push the completed code to the class repo.

1. Go over the code with the learners.
1. Point out the Arrange Act Assert pattern in each test method.

```java
@Test
    public void getAllMotorcycles() {

        Motorcycle moto = new Motorcycle();
        moto.setVin("22222");
        moto.setMake("Honda");
        moto.setModel("CB300");
        moto.setYear("2019");
        moto.setColor("red");

        dao.addMotorcycle(moto);

        moto = new Motorcycle();
        moto.setVin("33333");
        moto.setMake("Suzuki");
        moto.setModel("DR650");
        moto.setYear("2012");
        moto.setColor("gray");

        dao.addMotorcycle(moto);

        List<Motorcycle> motoList = dao.getAllMotorcycles();

        assertEquals(motoList.size(), 2);
    }

    @Test
    public void getMotorcyclesByMake() {
        Motorcycle moto = new Motorcycle();
        moto.setVin("22222");
        moto.setMake("Honda");
        moto.setModel("CB300");
        moto.setYear("2019");
        moto.setColor("red");

        dao.addMotorcycle(moto);

        moto = new Motorcycle();
        moto.setVin("33333");
        moto.setMake("Suzuki");
        moto.setModel("DR650");
        moto.setYear("2012");
        moto.setColor("gray");

        dao.addMotorcycle(moto);

        moto = new Motorcycle();
        moto.setVin("44444");
        moto.setMake("Suzuki");
        moto.setModel("DRZ 400");
        moto.setYear("2016");
        moto.setColor("black");

        dao.addMotorcycle(moto);

        List<Motorcycle> mList = dao.getMotorcyclesByMake("Suzuki");
        assertEquals(mList.size(), 2);

        mList = dao.getMotorcyclesByMake("Honda");
        assertEquals(mList.size(), 1);

        mList = dao.getMotorcyclesByMake("Ducati");
        assertEquals(mList.size(), 0);

    }


    @Test
    public void updateMotorcycle() {

        Motorcycle moto = new Motorcycle();
        moto.setVin("12345");
        moto.setMake("Honda");
        moto.setModel("Africa Twin");
        moto.setYear("2019");
        moto.setColor("black");

        moto = dao.addMotorcycle(moto);

        moto.setVin("99999");
        moto.setMake("UPDATED");
        moto.setModel("NEW MODEL");
        moto.setYear("1111");
        moto.setColor("NEW COLOR");

        dao.updateMotorcycle(moto);

        Motorcycle moto2 = dao.getMotorcycle(moto.getId());

        assertEquals(moto2, moto);
    }
```

---

## We Do: Database Configuration (15 min)
![code-along][code-along]

> The purpose of this section is to show learners how to configure the connection to MySQL using the application.properties file.

The database connection configuration for the application is contained in the ```src --> main --> resources --> application.properties``` file.

* Have everyone open this file and add the following entries:

```java
spring.datasource.url: jdbc:mysql://localhost:3306/moto_inventory
spring.datasource.username: root
spring.datasource.password: root
spring.datasource.driver-class-name: com.mysql.jdbc.Driver
```

The database connection configuration for the tests is contained in the ```src --> test --> resources --> application.properties``` file

* Have everyone open this file and add the following entries:

```java
spring.datasource.url: jdbc:mysql://localhost:3306/moto_inventory_test
spring.datasource.username: root
spring.datasource.password: root
spring.datasource.driver-class-name: com.mysql.jdbc.Driver
```
---

> Now we need to create the moto_inventory and moto_inventory_test schemas in their local database instances.

1. Have everyone open MySQL Workbench.
1. Have everyone create the following schemas:
    * moto_inventory
    * moto_inventory_test
1. Have everyone run the following SQL script agains both schemas.

```sql
create table if not exists motorcycle (
	id int not null auto_increment primary key,
    vin varchar(20) not null,
    make varchar(20) not null,
    model varchar(20) not null,
    year varchar(4) not null,
    color varchar(20) not null
);
```

> There are some compatability/configuration issues with some versions of the MySQL driver. Now we will make a POM change so that we use a version of the driver that does not have the problem.

1. Have everyone open their pom.xml file.
1. Have everyone change the entry for mysql-cnnector-java to the following:
    * Specifically, we are changing the version number.
    * Make sure everyone imports the POM changes or this change will not take effect.

```xml
		<dependency>
			<groupId>mysql</groupId>
			<artifactId>mysql-connector-java</artifactId>
			<version>5.1.39</version>
			<scope>runtime</scope>
		</dependency>

```

## Prepared Statements (15 min)

> Now we will begin implementing the DAO. The purpose of this section is to introduce the concept of prepared statements, point out why they must always be used in Java code, and show learners how to create prepared statement Strings.

### About Prepared Statements
Make the following points about prepared statements:

* Prepared statements are SQL statements that have placeholders for passing in the values that should be inserted into the database or used in the WHERE clause.
* In our case, we use prepared statements in conjunction with Spring JdbcTemplates, which give us a safe way to pass the parameters into the prepared statements.
* We never want to directly construct SQL statements from values given to us by the user. These values can contain malicious content that can result in a SQL injection attack on the database. These attacks can compromise the data in the database.
* Prepared statements give us a safe way to use data supplied by the user in SQL statements. The Spring JdbcTemplate code will "cleanse" the data passed in by the user, rendering any malicious data harmless.
* Repeat: ALWAYS USE PREPARED STATEMENTS!

---

## We Do: Create Prepared Statements (15 min)
![code-along][code-along]

> The purpose of this We Do is to show learners how to create prepared statements. We'll continue to use the Moto Inventory project. Show learners how to do INSERT_MOTO_SQL and then let them pair up for 10 minutes to create the rest of the the prepared statements. You can give them the names of the prepared statements and make sure to remind them that each method in the API will need a corresponding SQL statement. 
>
> After 10 minutes, go over the solution with the group.

Make the following points about the code:

* We have one prepared statement for each method in our DAO API.
* We are setting up String constants for each of our prepared statements at the top of the class.
    * INSERT_MOTO_SQL --> addMotorcycle
    * SELECT_MOTO_SQL --> getMotorcycle
    * SELECT_ALL_MOTOS_SQL --> getAllMotorcycles
    * DELETE_MOTO_SQL --> deleteMotorcycle
    * UPDATE_MOTO_SQL --> updateMotorcycle
    * SELECT_MOTOS_BY_MAKE_SQL --> getMotorcyclesByMake

```java
@Repository
public class MotoInventoryDaoJdbcTemplateImpl implements MotoInventoryDao {

    // Prepared statement strings
    private static final String INSERT_MOTO_SQL =
            "insert into motorcycle (vin, make, model, year, color) values (?, ?, ?, ?, ?)";

    private static final String SELECT_MOTO_SQL =
            "select * from motorcycle where id = ?";

    private static final String SELECT_ALL_MOTOS_SQL =
            "select * from motorcycle";

    private static final String DELETE_MOTO_SQL =
            "delete from motorcycle where id = ?";

    private static final String UPDATE_MOTO_SQL =
            "update motorcycle set vin = ?, make = ?, model = ?, year = ?, color = ? where id = ?";

    private static final String SELECT_MOTOS_BY_MAKE_SQL =
            "select * from motorcycle where make = ?";


    @Override
    public Motorcycle getMotorcycle(int id) {

        return null;
    }

    @Override
    public List<Motorcycle> getAllMotorcycles() {

        return null;
    }

    @Override
    public List<Motorcycle> getMotorcyclesByMake(String make) {

        return null;
    }

    @Override
    @Transactional
    public Motorcycle addMotorcycle(Motorcycle motorcycle) {

        return null;
    }

    @Override
    public void updateMotorcycle(Motorcycle motorcycle) {
    }

    @Override
    public void deleteMotorcycle(int id) {
    }

}
```

---

## BREAK (10 min) 
![break icon][break] 

---

## Row Mapper Method (15 min)

> The purpose of this section is to show learners how to implement and use row mapper methods to map database entry data to DTOs. The Spring JdbcTemplate methods enable us to pass a method reference to a method that maps a row in the database to a Java object. These methods are referred to as row mapper methods. These methods are simple; they just map columns in the database to properties on the Java object.

### About the Row Mapper Method
Make the following points about row mapper methods:

* One task that our application must do is map each row returned from the database into a corresponding Java object.
* JdbcTemplate methods give us a way to pass a method reference to a method that knows how to map a row to a Java object.
* These row mapper methods are pretty simple. They map the columns of the database to properties of a Java object.
* Each row from the database is returned in an object called a ResultSet.
* The ResultSet allows us to get the value of each column by using the column name.

---

## We Do: Implement Row Mapper Method (15 min)
![code-along][code-along]

> The purpose of this We Do is to show learners how to implement a row mapper method.

Refer back to the points above when coding this with learners and make the additional points:

* The name of the method is arbitrary.
* The method must have the ```ResultSet``` and ```int``` parameters, although you will rarely, if ever, use the ```int``` parameter.
* The method must declare that it throws a SQLException. Accessing the ResultSet methods can cause a SQLException.
* We instantiate an empty Motorcycle object and fill its values from the ResultSet.
* We return the Motorcycle object.
* We will see this method in action in the next section.

```java
private Motorcycle mapRowToMotorcycle(ResultSet rs, int rowNum) throws SQLException {
        Motorcycle moto = new Motorcycle();
        moto.setId(rs.getInt("id"));
        moto.setMake(rs.getString("make"));
        moto.setModel(rs.getString("model"));
        moto.setVin(rs.getString("vin"));
        moto.setYear(rs.getString("year"));
        moto.setColor(rs.getString("color"));

        return moto;
    }
```

---

## JdbcTemplate Methods (30 min)

> The purpose of this section is to show learners how to use the ```update```, ```queryForObject```, and ```query``` methods and prepared statements to create, read, update, and delete DTO database entries.

### About JdbcTemplate Methods
Make the following points about these JdbcTemplate methods:

* The JdbcTemplate class has a large number of methods; we will use ```update```, ```queryForObject```, and ```query```.
* These methods are used in conjunction with prepared statements (previous section) and row mapper methods (next section) to get data into and out of the database and convert that data to and from Java objects.
* The ```update``` method is used for both INSERT and UPDATE operations.
* The ```queryForObject``` method is used for a query where you expect exactly one result. No result or many results will cause an error.
* The ```query``` method is used for a query where you expect zero or more results.

---

## We Do: JdbcTemplate Methods (30 min)
![code-along][code-along]

> Learners have created the prepared statements and row mapper methods needed to implement our DAO. In this We Do, we will show them how to use JdbcTemplate methods, prepared statements, and the row mapper method to finish the implementation of our DAO.

> We'll code the DAO in stages. The code snippets below comprise the entire DAO.

> The first step is to inject a JdbcTemplate into out DAO. We briefly introduced the concept of dependency injection to learners with the unit test code earlier. We'll reinfoce that concept here.

Make the following points about the following code:

* In order to use a JdbcTemplate in our DAO, we must have a JdbcTemplate property on our DAO class.
* We will take advantage of the dependency injection features of Spring Boot and the Spring Framework.
* We briefly talked about dependency injection when we added a DAO property to our test class earlier, we'll take a closer look now:
    * Dependency injection (DI), which is also known as Inversion of Control (IoC) is a technique that make it easier to build loosely coupled, maintainable code.
    * The main idea is that our code stops managing the lifecycle of the objects on which it depends by letting Spring manage it.
    * For example:
        * Rather than hardcoding a JdbcTemplate object like this: ```JdbcTemplate jdbcTemplate = new JdbcTemplate();```, we allow Spring to instantiate the object and then hand it to us (or **inject** it into our class).
* Setting our class up for dependency injection involves three steps:
    * The ```@Repository``` annotation on our class. This lets Spring know it should be aware of our class.
    * The declaration of the ```private JdbcTemplate jdbcTemplate;``` class property.
        * Note that we only declare the property; we do not instantiate the JdbcTemplate!
    * We create a constructor that has a ```JdbcTemplate``` parameter. We set the class property to the value passed into the constructor.
    * We add the ```@Autowired``` annotation to our constructor.
        * This tells Spring to create an instance of the JdbcTemplate and pass it into our constructor when our class is instantiated.

```java
@Repository
public class MotoInventoryDaoJdbcTemplateImpl implements MotoInventoryDao {

    // Prepared statement strings
    private static final String INSERT_MOTO_SQL =
            "insert into motorcycle (vin, make, model, year, color) values (?, ?, ?, ?, ?)";

    private static final String SELECT_MOTO_SQL =
            "select * from motorcycle where id = ?";

    private static final String SELECT_ALL_MOTOS_SQL =
            "select * from motorcycle";

    private static final String DELETE_MOTO_SQL =
            "delete from motorcycle where id = ?";

    private static final String UPDATE_MOTO_SQL =
            "update motorcycle set vin = ?, make = ?, model = ?, year = ?, color = ? where id = ?";

    private static final String SELECT_MOTOS_BY_MAKE_SQL =
            "select * from motorcycle where make = ?";

    private JdbcTemplate jdbcTemplate;

    @Autowired
    public MotoInventoryDaoJdbcTemplateImpl(JdbcTemplate jdbcTemplate) {
        
        this.jdbcTemplate = jdbcTemplate;
    }
```

> The first method we will implement is ```getMotorcycle```. This method is a little more complicated than we might think at first glance. We use the ```queryForObject``` method, which expects exactly one result and throws an exception if there is no result. That is not how we'd like the method to work. We want to return null if there is no matching record. That means we need to catch the exception and process it.

Make the following points as you code this method with learners:

* We are starting with the ```getMotorcycle``` method.
* We are using the ```queryForObject``` method, which expects exactly one result.
* We pass in the SELECT_MOTO_SQL prepared statement, followed by our row mapper method, and finally by the value we want to pass into the prepared statement.
    * Take a moment to discuss the ```this::mapRowToMotorcycle``` syntax. This is how we get a method reference to a method on our class.
    * Remind them what the SELECT_MOTO_SQL prepared statement looks like (it has a placeholder for the Motorcycle id in the WHERE clause)
* Exception handling:
    * We need to catch the ```EmptyResultDataAccessException```, which gets thrown when there is no Motorcycle in the database for the given id.
    * We just return ```null``` if the exception is thrown.

> Go through the implementation of getMotorcycle as a group. Let the learners try the other methods on their own (5 minutes per method) to see if they can figure things out. Tell them to Google "Spring JdbcTemplate JavaDoc".

```java
    @Override
    public Motorcycle getMotorcycle(int id) {

       try {

           return jdbcTemplate.queryForObject(SELECT_MOTO_SQL, this::mapRowToMotorcycle, id);

       } catch (EmptyResultDataAccessException e) {
           // if nothing is returned just catch the exception and return null
           return null;
       }

    }
```

> Now we implement ```getAllMotorcycles```. This method is simpler than getMotorcycle because ```query``` doesn't throw an exception if there are no results (it just returns and empty list) and the SELECT_ALL_MOTOS_SQL has no parameters (there is no WHERE clause).

Make the following points as you code this method with learners:

* We're moving to ```getAllMotocycles```.
* We are expecting 0 or more results, so we use the ```query``` method.
* The SELECT_ALL_MOTOS_SQL has no parameters, so we pass only the prepared statement and our row mapper method to ```query```.


```java
    @Override
    public List<Motorcycle> getAllMotorcycles() {

        return jdbcTemplate.query(SELECT_ALL_MOTOS_SQL, this::mapRowToMotorcycle);
    }

```

> Now we implement ```getMotorcyclesByMake```. This is similar to the last two methods. We're using ```query```because we expect 0 or more results. We have to pass ```make``` into ```query``` because SELECT_MOTOS_BY_MAKE_SQL has a parameter in the WHERE clause.

Make the following points as you code this method with learners:

* We will now implement ```getMotorcyclesByMake```.
* We are expecting 0 or more results, so we use the ```query``` method.
* SELECT_MOTOS_BY_MAKE_SQL has one parameter in its WHERE clause, so we pass the prepared statement, the row mapper method, and the value for ```make``` to ```query```.

```java
    @Override
    public List<Motorcycle> getMotorcyclesByMake(String make) {

        return jdbcTemplate.query(SELECT_MOTOS_BY_MAKE_SQL, this::mapRowToMotorcycle, make);
    }

```

> Now we move onto the methods that create, update, and delete data in the database.  All of the **get** methods retrieved data from the database, used ```queryForObject```, ```query```, and the row mapper method. The following methods follow a different pattern. They use the ```update``` method and do not need the row mapper method.
>
> First up is the ```addMotorcycle``` method. This is a two-step process. First we insert the information into the database and then we ask the database for the auto_increment id value that was assigned to the new row. Because this is a two-step process, we must add the ```@Transactional``` annotation to the method. This ensures that both operations happen under the same transaction so we are guaranteed to get the right id value for our Motorcycle.

Make the following points about this method as you code it with learners:

* We will now implement ```addMotorcycle```.
* Methods that insert data into the database follow a different pattern than those that retrieve data from the database.
* We use the ```update``` method to insert data into the database.
    * We pass in the prepared statement and the values that we want to insert into the database.
    * Remind learners what the INSERT_MOTO_SQL prepared statement looks like.
* After the data has been inserted, we want to get the auto-generated id for the row.
    * We use ```queryForObject```, passing in a SQL select statement that calls the ```last_insert_id()``` MySQL function. This function gives us the id of the row we just inserted into the database. We also pass in the ```Integer.class``` so ```queryForObject``` knows what type to return to us.
* Once we have the id, we set it on the Motocycle object and then return it.

```java
   @Override
    @Transactional
    public Motorcycle addMotorcycle(Motorcycle motorcycle) {

        jdbcTemplate.update(INSERT_MOTO_SQL,
                motorcycle.getVin(),
                motorcycle.getMake(),
                motorcycle.getModel(),
                motorcycle.getYear(),
                motorcycle.getColor());

        int id = jdbcTemplate.queryForObject("select last_insert_id()", Integer.class);

        motorcycle.setId(id);

        return motorcycle;
    }

```

Now we implement ```updateMotorcycle```. This is similar to ```addMotorcycle``` except we don't need to ask the database for the assigned id because we are updating an existing row in the database.

```java
    @Override
    public void updateMotorcycle(Motorcycle motorcycle) {

        jdbcTemplate.update(UPDATE_MOTO_SQL,
                motorcycle.getVin(),
                motorcycle.getMake(),
                motorcycle.getModel(),
                motorcycle.getYear(),
                motorcycle.getColor(),
                motorcycle.getId());
    }

```

Finally, we implement ```deleteMotorcycle```. This is straighforward—we pass the prepared statement and the id of the row we want to delete.

```java
    @Override
    public void deleteMotorcycle(int id) {

        jdbcTemplate.update(DELETE_MOTO_SQL, id);
    }

```

---

## Instructor Do: Record Collection Introduction (15 min)
![show-code][show-code]

> We've shown the implementation of a simple DAO. Now we'll introduce a more complicated database (four tables) and ask the learners to implement the DAOs for each of the tables. We provide them with the DAO interfaces, model objects, and unit tests. They need to implement the DAOs until all the unit tests pass. 
>
> This is a pair-programming activity. We also supply the creation script for the database and all database connection configuration. Everything is in the start-code folder.

1. Open the database creation script and review it with learners.
1. Point out the tables and the FK constraints.
1. Open the project and review the following:
    * Each DAO interface—these all look similar to the Moto Inventory DAO
    * The model classes
    * The unit tests
        * The biggest point we want to make here is the complexity that the FK constraints bring to the Arrange part of AAA testing.
        * We have to be aware of what order we create and delete rows in the database.

---

## You Do: Finish Record Collection (120 min)
![code-along][code-along]

1. Pair people up.
1. Have them start implementing the DAOs.
1. Circulate, answer questions, and give guidance.

---

## Recap (10 min)
![take note icon][take-note]

The main takeaways from this lesson are:

* DAO APIs generally follow a pattern and contain methods that do the following:
    * Add a row to the database
    * Delete a row from the database
    * Get a row from the database by id
    * Get rows from the database by some criteria
    * Update an existing row in the database
* TDD and Red Green Refactor are techniques that improve both code quality and the confidence that we have in our code.
* Prepared statements should be used for all database queries in our applications. They help prevent SQL injection attacks.
* JdbcTemplate methods allow us to insert data into and retrieve data from database tables. They use prepared statements and row mapper methods.

---
© 2019 Trilogy Education Services

[present]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-present/res/mipmap-hdpi/icon-present.png "Present"

[discuss]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-discuss/res/mipmap-hdpi/icon-discuss.png "Discuss"

[take-note]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-take-note/res/mipmap-hdpi/icon-take-note.png "Take Note"

[show-code]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-show-code/res/mipmap-hdpi/icon-show-code.png "Show Code"

[code-along]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-code-along/res/mipmap-hdpi/icon-code-along.png "Code Along"

[starter-code]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-starter-code/res/mipmap-hdpi/icon-starter-code.png "Starter Code"

[kata]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-kata/res/mipmap-hdpi/icon-kata.png "Kata"

[time]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-time/res/mipmap-hdpi/icon-time.png "Time"

[warning]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-warning/res/mipmap-hdpi/icon-warning.png "Warning"

[break]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-break/res/mipmap-hdpi/icon-break.png "Break"

[alert]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/icon-alert/res/mipmap-hdpi/icon-alert.png

[need-code]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/need-code-300.png

[need-content]: https://github.com/coding-boot-camp/Java-s1/blob/master/id-resources/icons/need-content-300.png


