package com.company;

public class SwapAndPrint {

    public static void main(String[] args) {

        // Write code that does that following with an array of ints. Your code should work for an array of any size.
        //
        // 1. Prints the original array
        // 2. Swaps the first and last elements
        // 3. Prints the new array

        int [] numbers = {2, 4, 5, 3,
                7, 6, 1, 9,
                10, 13, 56, 43,
                17, 89, 3, 24,
                37, 12, 101, 112};

    }

}
