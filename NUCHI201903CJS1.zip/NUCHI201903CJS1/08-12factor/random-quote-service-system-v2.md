# Random Quote Service Project v2.0

The purpose of this project is to give you practice creating a Eureka Service Registry from scratch, creating and registering a web service with the Service Registry, and modifying an existing web service to use the Service Registry to locate the registered service and call it.

## Requirements

### Service Registry

1. Create a new Eureka Service Registry project called ```firstname-lastname-service-registry``` using the Spring Initializr following the steps outlined in the lesson.
2. Use the following configuration setting for the Service Registry:
   1. Run on port 8761
   2. Set the hostname to localhost
   3. All other settings should match those in your cheatsheet for this lesson

### Cloud Config Server

1. Use the Cloud Config Server created in the first version of this project to serve up config files to both the Random Quote Service and the Magic 8-Ball Service.

### Magic 8-Ball Service

1. Create new Spring Boot web service project called ```firstname-lastname-magic-eight-ball-service``` using the Spring Intitializr. This web service must include support for the service to register with the Eureka Service Registry.
2. The service must register with the Eureka Service Registry
3. The service must run on port 3344.
4. The service must have the following endpoint:

```java
URI: /eightballanswer
HTTP Method: GET
Request Body: None
Response Body: Answer (String)
```

4. The endpoint should randomly return one of the following answers:
   1. No
   2. Yes
   3. Looking cloudy
   4. Not sure
   5. Absolutely!
   6. Ask again
   7. Ummm
   8. Not a chance

### Random Quote Service Modifications

1. Add the following endpoint to version 1 of the Random Quote Service:

```java
URI: /answerme
HTTP Method: GET
Request Body: None
Response Body: Answer (String)
```

2. This endpoint must do the following:
   1. Call the Magic 8-Ball Service /eightballanswer endpoint and return the result to the caller.

 