package com.company;
import java.util.Scanner;

public class DoubleAndAddFive {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num1 = Integer.parseInt(scan.nextLine());

        System.out.format("Your number doubled plus five is %d", 2*num1 + 5);
    }
}
