# Lesson Overview: Joins
The purpose of this lesson is to give learners a high-level concpetual view of joins. Joins are presented in relationship to normalization. Whereas normalization spreads data across several tables for data storage efficiency, joins gather that information back together so it is easy to read.

## Topics

* Inner joins
* Outer joins

## Assessments

* In-class exercise with video store data model

## Required Software and Resources

* PDF viewer

## Approach

This lesson talks about concept of join. It does not cover SQL join syntax. Joins are presented as the process in which data is gathered from two tables that are connected by a relationship. Joins reassemble data that was split over several tables so that it is easier for humans to read.

## Assumptions

* Basic understanding of relational databases including:
  * Tables
  * Columns
  * Keys (primary and foreign)
  * Relationships
* Basic understanding of First, Second, and Third Normal Form 

---

© 2019 Trilogy Education Services
