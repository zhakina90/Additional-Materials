package com.company;
import java.util.Scanner;

public class VirtualPet {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Tell me a little about your Virtual Pet.");

        System.out.print("What type of pet do you have? ");
        String type = scan.nextLine();

        System.out.print("What is your pet's name? ");
        String name = scan.nextLine();

        System.out.print("How old is your pet? ");
        int age = Integer.parseInt(scan.nextLine());

        System.out.print("How much does your pet weigh in pounds? ");
        int weight = Integer.parseInt(scan.nextLine());

        System.out.println("----------------------------");
        System.out.format("Your pet is a %s.%n", type);
        System.out.format("Their name is %s.%n", name);
        System.out.format("%s is %d years old %n", name, age);
        System.out.format("%s weighs %d pounds.%n", name, weight);
    }
}
