package com.example.cinder;

import com.example.cinder.domain.Dislike;
import com.example.cinder.domain.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

@RestController
@CrossOrigin
public class CinderApplicationController {

    @RequestMapping(value = "/api/profile", method = RequestMethod.PUT)
    @ResponseStatus(value = HttpStatus.CREATED)
    public void putProfile(@RequestBody Profile profile) {
        System.out.println("Here we are!");

        System.out.println("Got this profile: hiking - " + profile.getHiking() + ", dancing: " + profile.getDancing() + ", sports: " + profile.getSports());
        profile.setId(1);
        System.out.println("DONE!");

    }

    @RequestMapping(value = "/api/profile", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public Profile getProfile() {
        Profile returnVal = new Profile();
        returnVal.setHiking(1);
        returnVal.setDancing(2);
        returnVal.setSports(3);
        returnVal.setReading(4);
        returnVal.setQuietNight(5);
        returnVal.setDining(4);
        returnVal.setDebate(3);
        returnVal.setClub(2);
        returnVal.setPolitics(1);
        returnVal.setBeach(2);
        returnVal.setParties(3);
        return returnVal;
    }

    @RequestMapping(value = "/api/match", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public List<Profile> getMatches() {
        List<Profile> returnVal = new ArrayList<>();
        Profile a = new Profile();
        a.setName("Dan");
        a.setAge(41);
        a.setBio("Likes food.");
        returnVal.add(a);
        a = new Profile();
        a.setName("Sal");
        a.setAge(32);
        a.setBio("Also likes food.");
        returnVal.add(a);

        return returnVal;
    }

    @RequestMapping(value = "/api/dislike", method = RequestMethod.PUT)
    @ResponseStatus(value = HttpStatus.OK)
    public void putDislike(@RequestBody Dislike dislike) {
        System.out.println("Here we are!");

        System.out.println("Got this dislike: " + dislike.getPersonId());
        System.out.println("DONE!");

    }

}
