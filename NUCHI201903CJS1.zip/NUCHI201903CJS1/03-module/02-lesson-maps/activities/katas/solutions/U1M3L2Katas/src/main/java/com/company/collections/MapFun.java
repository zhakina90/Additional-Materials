package com.company.collections;

import java.util.*;

public class MapFun {

    public static void main(String[] args) {

        Map<String, Integer> cars = new HashMap<>();

        cars.put("Toyota Camry", 2012);
        cars.put("Chevy Camaro", 1969);
        cars.put("Hyundai Genesis ", 2015);
        cars.put("Jeep Wrangler", 2003);
        cars.put("Honda Civic", 2018);
        cars.put("Pontiac GTO", 1964);

        printKeyValuePairs(cars);
        System.out.println("------------------");

        cars.put("Ford Explorer", 2012);
        cars.put("Smart Fortwo", 2013);

        printKeyValuePairs(cars);
        System.out.println("------------------");

        cars.remove("Jeep Wrangler");

        printKeyValuePairs(cars);
    }

    private static void printKeyValuePairs(Map<String, Integer> map) {
        Set<Map.Entry<String, Integer>> myEntries = map.entrySet();
        for (Map.Entry<String, Integer> entry : myEntries) {
            System.out.println("Key = " + entry.getKey() + " : " + " Value = " + entry.getValue());
        }
    }
}
