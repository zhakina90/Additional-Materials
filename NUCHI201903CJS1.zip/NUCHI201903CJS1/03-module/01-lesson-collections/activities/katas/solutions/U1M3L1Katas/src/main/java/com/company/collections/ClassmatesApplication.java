package com.company.collections;

import java.util.*;

public class ClassmatesApplication {

    public static void main(String[] args) {

        List<Classmate> classList = new ArrayList<>();

        classList.add(new Classmate("George", "Black"));
        classList.add(new Classmate("Fred", "Purple"));
        classList.add(new Classmate("Tim", "Orange"));
        classList.add(new Classmate("Sue", "Blue"));
        classList.add(new Classmate("Krista", "Red"));

        for(Classmate student : classList) {
            System.out.format("%s has %s hair color%n", student.getName(), student.getHairColor());
        }
    }
}
