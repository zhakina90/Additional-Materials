package com.example.carlot;

import com.example.carlot.dao.CarRepository;
import com.example.carlot.dto.Car;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class CarLotController {

    @Autowired
    CarRepository carRepo;

    @RequestMapping(value="/car", method = RequestMethod.POST)
    public Car createCar(@RequestBody Car car) {
        System.out.println("We got a car!" + car.getMake() + car.getModel());
        carRepo.save(car);
//        customerRepo.save(customer);
        return car;
    }

    @RequestMapping(value="/car/{id}", method = RequestMethod.GET)
    public Car getCarById(@PathVariable(name="id") int id) {
        return carRepo.findOne(id); //customerRepo.findOne(id);
    }

    @RequestMapping(value="/car/{id}", method = RequestMethod.PUT)
    public Car getCarById(@PathVariable(name="id") int id, @RequestBody Car car) {
        car.setId(id); //customerRepo.findOne(id);
        return carRepo.save(car);
    }

}
