select 'Hello, world.';

-- below selects all data from products
select * from northwind.products;

-- select just some columns
select product_code, product_name, quantity_per_unit from northwind.products;

select * from northwind.employees;

select * from northwind.customer;
SELECT
	first_name, last_name, first_name, first_name, phone
from
	northwind.employees;
    
select * from northwind.orders;


select * from northwind.products where category='Camera';

select * from northwind.employees where job_title='Design Engineer';

select * from northwind.employees where state='Texas' or state='Minnesota';

select * from northwind.employees where state='Texas' and department='Baby';

select * from northwind.orders where shipping_fee between 6 and 8;

select * from northwind.orders where ship_country in ('Peru','Poland');
select * from northwind.orders where ship_country = 'Peru' or ship_country = 'Poland';

select * from northwind.orders where ship_country = 'Brazil';
select * from northwind.orders where ship_name in ('Alice Warren','Wanda Hill');
select * from northwind.customers where state in ('Ohio', 'Iowa','Texas');

-- all of theses city start with o
select * from northwind.customers where city LIKE 'O%';

-- all of these cities contain o
select * from northwind.customers where city like '%O%';

-- all of these cities end with o
select * from northwind.customers where city like '%O';

select * from northwind.customers where email like '%.co.uk';

select * from northwind.orders where ship_city like 'S_n%';

select * from northwind.orders where ship_city like 'S%n%';

-- don't use quotes with numbers!
select * from northwind.orders where employee_id=201;
select * from northwind.orders where employee_id='201';

-- count results - all orders taken by employee with id 201
select count(*) from northwind.orders where employee_id=201;
select count(*) from northwind.orders;


select * from northwind.employees where employee_id=201;
select * from northwind.employees where id=201;

-- this won't do what you want it to do! use like!
select * from northwind.orders where ship_city ='S%n%';

select * from northwind.customers where last_name like 'Si%';
select * from northwind.employees where email like '%.edu';

select * from northwind.customers where last_name like 'S%';

-- to_lower to_upper

select first_name, last_name from northwind.employees order by last_name;
select first_name, last_name from northwind.employees order by last_name asc;
select first_name, last_name from northwind.employees order by last_name desc;

select category, product_name from northwind.products 
	order by category asc, product_name asc;
    
select * from employees order by last_name;

select first_name, last_name from northwind.employees
where last_name like 'H%'
order by first_name desc;

select * from northwind.orders
	inner join northwind.employees on orders.employee_id = employees.id
where employees.last_name='Henry';

select employees.first_name, employees.last_name, orders.id from northwind.employees
	left outer join northwind.orders on orders.employee_id = employees.id;
    
insert into employees (first_name, last_name, email, id) values ('Dan', 'Mueller','dmueller@trilogyed.com', 999);
commit;

select * from orders;
select * from employees where last_name = 'Henry';
select * from employees where id=206;
select ship_name from orders where employee_id=206;


select * from products;
select * from order_details;

-- get the order_detail_status from order_details that have the product macbook pro in them

select order_detail_status from northwind.order_details
inner join northwind.products on order_details.product_id=products.id
where products.product_name='Macbook Pro';
select count(*) from northwind.order_details
inner join northwind.products on order_details.product_id=products.id
where products.product_name='Macbook Pro';
select * from products where product_name='MacBook Pro' and id=610;
select * from order_details where product_id=610;
select count(*) from order_details where product_id=610;

select * from orders;

select * from customers; -- get the last name and company of all the customers who had their orders shipped to Brazil
select customers.last_name, customers.company, orders.ship_country
from northwind.customers
inner join northwind.orders on customers.id=orders.customer_id
where orders.ship_country in ('Brazil', 'Venezuela');

use car_lot;
insert into car_lot.car (id, make, model, model_year, color)
values (1, 'Honda', 'Civic', '2020', 'blue');

insert into car_lot.car (id, make, model, model_year, color)
values (2, 'Lamborghini', 'Urus', '2020', 'matte black');

insert into car_lot.car (id, make, model, model_year)
values (3, 'Hyundai', 'Sonata', '2010');
insert into car_lot.car (id, make, model, model_year)
values (4, 'Honda', 'Accord', '2000');

insert into car_lot.car (id, make, model, model_year)
values (5, 'Nissan', 'Versa', '2009');

delete from car_lot.car where id=2;
delete from car_lot.car where id=1;
select * from car_lot.car;

delete from car_lot.car where color='matte black';


update car_lot.car
set color='Signet Silver'
where id=3;

update car_lot.car
set color='Brown'
where id in (1,2);

-- update id 3 to model Accent
update car_lot.car
set model='Accent'
where id=3;
-- set SQL_SAFE_UPDATE=0;

insert into car_lot.car (id, make, model, model_year, color)
values (1, 'Honda', 'Civic', '2020', 'blue');

insert into car_lot.car (id, make, model, model_year, color)
values (2, 'Lamborghini', 'Urus', '2020', 'matte black');

insert into car_lot.car (id, make, model, model_year)
values (3, 'Hyundai', 'Sonata', '2010');
insert into car_lot.car (id, make, model, model_year)
values (4, 'Honda', 'Accord', '2000');

insert into car_lot.car (id, make, model, model_year)
values (5, 'Nissan', 'Versa', '2009');

delete from car_lot.car where id=2;
delete from car_lot.car where id=1;
select * from car_lot.car;

delete from car_lot.car where color='matte black';


update car_lot.car
set color='Signet Silver'
where id=3;

update car_lot.car
set color='Brown'
where id in (1,2);

-- update id 3 to model Accent
update car_lot.car
set model='Accent'
where id=3;
-- set SQL_SAFE_UPDATE=0;
